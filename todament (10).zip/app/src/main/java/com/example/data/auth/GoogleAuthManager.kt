package com.example.data.auth

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class GoogleAuthManager(private val context: Context) {
  private val credentialManager = CredentialManager.create(context)

  fun signInWithGoogle(
    activity: Activity,
    scope: CoroutineScope,
    onSuccess: (email: String, displayName: String) -> Unit,
    onError: (String) -> Unit,
    onCancelled: () -> Unit = {}
  ) {
    val clientId = try {
      context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
      onError("Google Sign-In configuration missing: default_web_client_id not found")
      return
    }

    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder().addCredentialOption(signInOption).build()

    scope.launch {
      try {
        val result = credentialManager.getCredential(activity, request)
        val credential = result.credential
        if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
          val googleIdTokenObj = GoogleIdTokenCredential.createFrom(credential.data)
          var email = googleIdTokenObj.id
          var displayName = googleIdTokenObj.displayName ?: email.substringBefore("@")
          val googleIdToken = googleIdTokenObj.idToken

          try {
            val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
            val authResult = Firebase.auth.signInWithCredential(authCredential).await()
            val firebaseUser = authResult.user
            if (!firebaseUser?.email.isNullOrBlank()) {
              email = firebaseUser!!.email!!
            }
            if (!firebaseUser?.displayName.isNullOrBlank()) {
              displayName = firebaseUser!!.displayName!!
            }
          } catch (firebaseEx: Exception) {
            Log.w("Auth", "Firebase auth token sync note: ${firebaseEx.message}; proceeding with device verified Google identity")
          }
          onSuccess(email, displayName)
        } else {
          onError("Unexpected credential type returned from Google")
        }
      } catch (e: GetCredentialCancellationException) {
        Log.w("Auth", "Google Sign-In flow cancelled or dismissed: ${e.message}", e)
        onCancelled()
      } catch (e: Exception) {
        Log.e("Auth", "Google Sign-In failed", e)
        onError(e.localizedMessage ?: "Google Sign-In failed")
      }
    }
  }

  fun signOut(scope: CoroutineScope, onComplete: () -> Unit) {
    Firebase.auth.signOut()
    scope.launch {
      try {
        credentialManager.clearCredentialState(ClearCredentialStateRequest())
      } catch (e: Exception) {
        Log.e("Auth", "Failed to clear credential state", e)
      } finally {
        onComplete()
      }
    }
  }
}
