package com.example.ui.screens.admin

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.MatchFormat
import com.example.data.model.MatchStatus
import com.example.data.model.Tournament
import com.example.ui.components.FormatBadge
import com.example.ui.components.MapBadge
import com.example.ui.components.StatusBadge
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CarbonBackground
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonCard
import com.example.ui.theme.CarbonCardElevated
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.TodamentViewModel
import java.util.UUID

@Composable
fun AdminMatchesTab(viewModel: TodamentViewModel) {
  val tournaments by viewModel.tournaments.collectAsState()

  var showCreateDialog by remember { mutableStateOf(false) }
  var tournamentToEdit by remember { mutableStateOf<Tournament?>(null) }
  var tournamentToRoomCreds by remember { mutableStateOf<Tournament?>(null) }
  var tournamentToCancel by remember { mutableStateOf<Tournament?>(null) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CarbonBackground)
  ) {
    // Action bar to create new match
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 10.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "ACTIVE & UPCOMING MATCHES",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = TextPrimary
      )

      Button(
        onClick = { showCreateDialog = true },
        colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground),
        shape = RoundedCornerShape(8.dp),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
        modifier = Modifier.testTag("btn_admin_create_match")
      ) {
        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = "CREATE MATCH", fontWeight = FontWeight.Bold, fontSize = 12.sp)
      }
    }

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 90.dp)
    ) {
      if (tournaments.isEmpty()) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(40.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(text = "No matches created yet.", color = TextMuted)
          }
        }
      } else {
        items(tournaments) { tourn ->
          AdminMatchCardItem(
            tournament = tourn,
            onEdit = { tournamentToEdit = tourn },
            onUpdateRoom = { tournamentToRoomCreds = tourn },
            onCancel = { tournamentToCancel = tourn }
          )
        }
      }
    }
  }

  // CREATE / EDIT MATCH DIALOG
  if (showCreateDialog || tournamentToEdit != null) {
    MatchEditDialog(
      existing = tournamentToEdit,
      onDismiss = {
        showCreateDialog = false
        tournamentToEdit = null
      },
      onSave = { match ->
        if (tournamentToEdit != null) {
          viewModel.updateMatch(match) {
            tournamentToEdit = null
          }
        } else {
          viewModel.createMatch(match) {
            showCreateDialog = false
          }
        }
      }
    )
  }

  // ROOM CREDENTIALS DIALOG
  tournamentToRoomCreds?.let { tourn ->
    RoomCredentialsDialog(
      tournament = tourn,
      onDismiss = { tournamentToRoomCreds = null },
      onSave = { rId, rPass, isVisible ->
        viewModel.updateRoomCredentials(tourn.id, rId, rPass, isVisible)
        tournamentToRoomCreds = null
      }
    )
  }

  // CANCEL & REFUND CONFIRMATION DIALOG
  tournamentToCancel?.let { tourn ->
    AlertDialog(
      onDismissRequest = { tournamentToCancel = null },
      containerColor = CarbonCardElevated,
      title = {
        Text(text = "Cancel Match & Auto-Refund?", fontWeight = FontWeight.Black, color = CrimsonAlert)
      },
      text = {
        Text(
          text = "Are you sure you want to cancel '${tourn.title}'? This will automatically refund entry fees back to all ${tourn.filledSlots} registered players' in-app wallets immediately.",
          color = TextSecondary
        )
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.cancelMatchAndRefund(tourn.id)
            tournamentToCancel = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert, contentColor = Color.White),
          modifier = Modifier.testTag("btn_confirm_cancel_match")
        ) {
          Text("YES, CANCEL & REFUND", fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { tournamentToCancel = null }) {
          Text("KEEP MATCH", color = TextSecondary)
        }
      }
    )
  }
}

@Composable
fun AdminMatchCardItem(
  tournament: Tournament,
  onEdit: () -> Unit,
  onUpdateRoom: () -> Unit,
  onCancel: () -> Unit
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = CarbonCard),
    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, CarbonBorder))),
    shape = RoundedCornerShape(12.dp),
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 5.dp)
      .testTag("admin_match_card_${tournament.id}")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          FormatBadge(format = tournament.format)
          MapBadge(mapName = tournament.mapName)
        }
        StatusBadge(status = tournament.status)
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(text = tournament.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
      Text(text = "${tournament.matchDate} • Start: ${tournament.startTime} • Slots: ${tournament.filledSlots}/${tournament.totalSlots}", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)

      Spacer(modifier = Modifier.height(10.dp))

      // Action Buttons Row: Edit, Room Creds, Cancel
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        // PROMINENT EDIT BUTTON (Section 8 Requirement)
        Button(
          onClick = onEdit,
          colors = ButtonDefaults.buttonColors(containerColor = CarbonCardElevated, contentColor = NeonCyan),
          border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(NeonCyan.copy(alpha = 0.5f), NeonCyan.copy(alpha = 0.5f)))),
          shape = RoundedCornerShape(8.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
          modifier = Modifier
            .weight(1f)
            .testTag("btn_edit_match_${tournament.id}")
        ) {
          Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text(text = "EDIT", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        // Room credentials button
        Button(
          onClick = onUpdateRoom,
          colors = ButtonDefaults.buttonColors(containerColor = CarbonCardElevated, contentColor = EmeraldNeon),
          border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(EmeraldDark, EmeraldDark))),
          shape = RoundedCornerShape(8.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
          modifier = Modifier
            .weight(1.3f)
            .testTag("btn_room_creds_${tournament.id}")
        ) {
          Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text(text = if (tournament.roomId.isNotBlank()) "ROOM: ${tournament.roomId}" else "SET ROOM", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        // Cancel & Auto-Refund button
        if (tournament.status != MatchStatus.CANCELLED && tournament.status != MatchStatus.COMPLETED) {
          Button(
            onClick = onCancel,
            colors = ButtonDefaults.buttonColors(containerColor = CarbonCardElevated, contentColor = CrimsonAlert),
            border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(CrimsonAlert.copy(alpha = 0.4f), CrimsonAlert.copy(alpha = 0.4f)))),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
            modifier = Modifier.testTag("btn_cancel_match_${tournament.id}")
          ) {
            Icon(Icons.Default.Cancel, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = "CANCEL", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun MatchEditDialog(
  existing: Tournament?,
  onDismiss: () -> Unit,
  onSave: (Tournament) -> Unit
) {
  var title by remember { mutableStateOf(existing?.title ?: "") }
  var mapName by remember { mutableStateOf(existing?.mapName ?: "Bermuda") }
  var format by remember { mutableStateOf(existing?.format ?: MatchFormat.SQUAD) }
  var entryFeeStr by remember { mutableStateOf(existing?.entryFee?.toInt()?.toString() ?: "100") }
  var totalPrizeStr by remember { mutableStateOf(existing?.totalPrizePool?.toInt()?.toString() ?: "3500") }
  var firstPrizeStr by remember { mutableStateOf(existing?.firstPrize?.toInt()?.toString() ?: "1800") }
  var secondPrizeStr by remember { mutableStateOf(existing?.secondPrize?.toInt()?.toString() ?: "1000") }
  var thirdPrizeStr by remember { mutableStateOf(existing?.thirdPrize?.toInt()?.toString() ?: "400") }
  var perKillStr by remember { mutableStateOf(existing?.perKillBonus?.toInt()?.toString() ?: "30") }
  var matchDate by remember { mutableStateOf(existing?.matchDate ?: "2026-10-25") }
  var startTime by remember { mutableStateOf(existing?.startTime ?: "21:00 IST") }
  var closingTime by remember { mutableStateOf(existing?.registrationClosingTime ?: "20:45 IST") }
  var totalSlotsStr by remember { mutableStateOf(existing?.totalSlots?.toString() ?: "12") }
  var rules by remember { mutableStateOf(existing?.customRules ?: "1. Mobile devices only\n2. Gun skin attributes: OFF\n3. Character skills: ON") }
  var status by remember { mutableStateOf(existing?.status ?: MatchStatus.OPEN) }

  val scrollState = rememberScrollState()

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = CarbonCardElevated,
      border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, EmeraldDark))),
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 12.dp)
    ) {
      Column(
        modifier = Modifier
          .padding(18.dp)
          .verticalScroll(scrollState)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (existing != null) "Edit Match Details" else "Create New Tournament",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Black,
            color = TextPrimary
          )
          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Match Title") },
          colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Map and Format pickers
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = mapName,
            onValueChange = { mapName = it },
            label = { Text("Map (Bermuda/Purgatory...)") },
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
            singleLine = true,
            modifier = Modifier.weight(1f)
          )

          OutlinedTextField(
            value = totalSlotsStr,
            onValueChange = { totalSlotsStr = it },
            label = { Text("Total Slots") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
            singleLine = true,
            modifier = Modifier.weight(1f)
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Date & Time
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = matchDate,
            onValueChange = { matchDate = it },
            label = { Text("Match Date") },
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
            singleLine = true,
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = startTime,
            onValueChange = { startTime = it },
            label = { Text("Start Time") },
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
            singleLine = true,
            modifier = Modifier.weight(1f)
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Financials: Entry Fee, Total Prize, 1st, 2nd, 3rd, Per Kill
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = entryFeeStr,
            onValueChange = { entryFeeStr = it },
            label = { Text("Entry Fee (₹)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
            singleLine = true,
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = totalPrizeStr,
            onValueChange = { totalPrizeStr = it },
            label = { Text("Prize Pool (₹)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
            singleLine = true,
            modifier = Modifier.weight(1f)
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = firstPrizeStr,
            onValueChange = { firstPrizeStr = it },
            label = { Text("1st Prize (₹)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
            singleLine = true,
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = perKillStr,
            onValueChange = { perKillStr = it },
            label = { Text("Per Kill (₹)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
            singleLine = true,
            modifier = Modifier.weight(1f)
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = rules,
          onValueChange = { rules = it },
          label = { Text("Custom Rules") },
          colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
          modifier = Modifier.fillMaxWidth(),
          maxLines = 4
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
          onClick = {
            val updated = Tournament(
              id = existing?.id ?: UUID.randomUUID().toString(),
              title = title.ifBlank { "Free Fire Scrim" },
              mapName = mapName.ifBlank { "Bermuda" },
              format = format,
              entryFee = entryFeeStr.toDoubleOrNull() ?: 100.0,
              totalPrizePool = totalPrizeStr.toDoubleOrNull() ?: 3500.0,
              firstPrize = firstPrizeStr.toDoubleOrNull() ?: 1800.0,
              secondPrize = secondPrizeStr.toDoubleOrNull() ?: 1000.0,
              thirdPrize = thirdPrizeStr.toDoubleOrNull() ?: 400.0,
              perKillBonus = perKillStr.toDoubleOrNull() ?: 30.0,
              matchDate = matchDate,
              startTime = startTime,
              registrationClosingTime = closingTime,
              matchTimestamp = existing?.matchTimestamp ?: (System.currentTimeMillis() + 3600000),
              totalSlots = totalSlotsStr.toIntOrNull() ?: 12,
              filledSlots = existing?.filledSlots ?: 0,
              status = status,
              customRules = rules,
              roomId = existing?.roomId ?: "",
              roomPassword = existing?.roomPassword ?: "",
              isRoomVisible = existing?.isRoomVisible ?: false
            )
            onSave(updated)
          },
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag("btn_save_match_dialog")
        ) {
          Text(text = if (existing != null) "SAVE CHANGES" else "PUBLISH MATCH", fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
fun RoomCredentialsDialog(
  tournament: Tournament,
  onDismiss: () -> Unit,
  onSave: (String, String, Boolean) -> Unit
) {
  var roomId by remember { mutableStateOf(tournament.roomId) }
  var roomPassword by remember { mutableStateOf(tournament.roomPassword) }
  var isVisible by remember { mutableStateOf(tournament.isRoomVisible) }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = CarbonCardElevated,
    title = {
      Text(text = "Broadcast Room Credentials", fontWeight = FontWeight.Black, color = TextPrimary)
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text(text = "Match: ${tournament.title}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = roomId,
          onValueChange = { roomId = it },
          label = { Text("Room ID") },
          placeholder = { Text("e.g. 981245") },
          colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_admin_room_id")
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = roomPassword,
          onValueChange = { roomPassword = it },
          label = { Text("Room Password") },
          placeholder = { Text("e.g. win24") },
          colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_admin_room_pass")
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(text = "Reveal to Registered Players", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(text = "When ON, players see credentials on match card", style = MaterialTheme.typography.labelSmall, color = TextMuted)
          }
          Switch(
            checked = isVisible,
            onCheckedChange = { isVisible = it },
            colors = SwitchDefaults.colors(checkedThumbColor = EmeraldNeon, checkedTrackColor = EmeraldDark)
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { onSave(roomId, roomPassword, isVisible) },
        colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground),
        modifier = Modifier.testTag("btn_save_room_creds")
      ) {
        Text("BROADCAST TO SQUADS", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("CANCEL", color = TextSecondary)
      }
    }
  )
}
