package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.AppSettings
import com.example.data.model.DepositRequest
import com.example.data.model.MatchFormat
import com.example.data.model.MatchStatus
import com.example.data.model.PromotionalBanner
import com.example.data.model.Registration
import com.example.data.model.Tournament
import com.example.data.model.TransactionType
import com.example.data.model.User
import com.example.data.model.WalletTransaction
import com.example.data.model.WithdrawalRequest
import com.example.data.repository.TodamentRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.filterNotNull
import com.example.data.auth.GoogleAuthManager
import com.example.data.firestore.FirestoreSyncManager
import com.example.data.local.SessionManager
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TodamentViewModel(application: Application) : AndroidViewModel(application) {
  private val database = AppDatabase.getDatabase(application)
  val firestoreSyncManager = FirestoreSyncManager(application, database)
  val sessionManager = SessionManager.getInstance(application)
  val googleAuthManager = GoogleAuthManager(application)
  val repository = TodamentRepository(database, firestoreSyncManager)

  private val _currentUserEmail = MutableStateFlow<String?>(null)
  val currentUserEmail: StateFlow<String?> = _currentUserEmail.asStateFlow()

  val currentUser: StateFlow<User?> = _currentUserEmail
    .flatMapLatest { email ->
      if (email != null) repository.getUser(email) else flowOf(null)
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val tournaments: StateFlow<List<Tournament>> = repository.getAllTournaments()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private val _selectedCategory = MutableStateFlow("All")
  val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

  val filteredTournaments: StateFlow<List<Tournament>> = combine(tournaments, _selectedCategory) { list, category ->
    when (category) {
      "Solo" -> list.filter { it.format == MatchFormat.SOLO }
      "Duo" -> list.filter { it.format == MatchFormat.DUO }
      "Squad" -> list.filter { it.format == MatchFormat.SQUAD }
      "Clash Squad" -> list.filter { it.format == MatchFormat.CLASH_SQUAD }
      else -> list
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val banners: StateFlow<List<PromotionalBanner>> = repository.getActiveBanners()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val appSettings: StateFlow<AppSettings> = repository.getAppSettings()
    .filterNotNull()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

  private val _transactionFilter = MutableStateFlow("All")
  val transactionFilter: StateFlow<String> = _transactionFilter.asStateFlow()

  val userTransactions: StateFlow<List<WalletTransaction>> = _currentUserEmail
    .flatMapLatest { email ->
      if (email != null) repository.getTransactions(email) else flowOf(emptyList())
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val filteredTransactions: StateFlow<List<WalletTransaction>> = combine(userTransactions, _transactionFilter) { list, filter ->
    when (filter) {
      "Deposits" -> list.filter { it.type == TransactionType.DEPOSIT }
      "Winnings" -> list.filter { it.type == TransactionType.WINNING }
      "Entry Fees" -> list.filter { it.type == TransactionType.ENTRY_FEE }
      "Refunds" -> list.filter { it.type == TransactionType.REFUND }
      "Referrals" -> list.filter { it.type == TransactionType.REFERRAL_BONUS }
      else -> list
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val userRegistrations: StateFlow<List<Registration>> = _currentUserEmail
    .flatMapLatest { email ->
      if (email != null) repository.getRegistrationsForUser(email) else flowOf(emptyList())
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val userDeposits: StateFlow<List<DepositRequest>> = _currentUserEmail
    .flatMapLatest { email ->
      if (email != null) repository.getDepositRequests(email) else flowOf(emptyList())
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val userWithdrawals: StateFlow<List<WithdrawalRequest>> = _currentUserEmail
    .flatMapLatest { email ->
      if (email != null) repository.getWithdrawalRequests(email) else flowOf(emptyList())
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Admin Streams
  val allUsers: StateFlow<List<User>> = repository.getAllUsers()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allDepositRequests: StateFlow<List<DepositRequest>> = repository.getAllDepositRequests()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allWithdrawalRequests: StateFlow<List<WithdrawalRequest>> = repository.getAllWithdrawalRequests()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allTransactions: StateFlow<List<WalletTransaction>> = repository.getAllTransactions()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allBanners: StateFlow<List<PromotionalBanner>> = repository.getAllBanners()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // UI Toast / Alerts
  private val _uiMessage = MutableStateFlow<String?>(null)
  val uiMessage: StateFlow<String?> = _uiMessage.asStateFlow()

  private val _errorMessage = MutableStateFlow<String?>(null)
  val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

  private val _isLoading = MutableStateFlow(false)
  val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

  init {
    viewModelScope.launch {
      repository.initializeDefaultData()
      // Start real-time cloud database sync
      firestoreSyncManager.startRealtimeSync(viewModelScope)

      // Restore saved user session across restarts or re-installs
      val savedEmail = sessionManager.getLoggedInUserEmail()
      if (!savedEmail.isNullOrBlank()) {
        val user = repository.getUserSync(savedEmail) ?: firestoreSyncManager.fetchUserFromCloud(savedEmail)
        if (user != null) {
          _currentUserEmail.value = user.email
        }
      }
    }
  }

  fun clearMessages() {
    _uiMessage.value = null
    _errorMessage.value = null
  }

  fun selectCategory(category: String) {
    _selectedCategory.value = category
  }

  fun selectTransactionFilter(filter: String) {
    _transactionFilter.value = filter
  }

  // --- Auth Actions ---
  fun login(email: String, password: String = "") {
    viewModelScope.launch {
      _isLoading.value = true
      val result = repository.loginUser(email, password)
      _isLoading.value = false
      result.onSuccess {
        sessionManager.saveSession(it.email)
        _currentUserEmail.value = it.email
        _uiMessage.value = "Welcome back, ${it.freeFireIgn}!"
      }.onFailure {
        _errorMessage.value = it.message ?: "Login failed"
      }
    }
  }

  fun register(
    email: String,
    fullName: String,
    phone: String,
    ffUid: String,
    ffIgn: String,
    password: String = "",
    referralCode: String = ""
  ) {
    viewModelScope.launch {
      _isLoading.value = true
      val result = repository.registerUser(
        email = email,
        fullName = fullName,
        phone = phone,
        ffUid = ffUid,
        ffIgn = ffIgn,
        password = password,
        referredByCode = referralCode
      )
      _isLoading.value = false
      result.onSuccess {
        sessionManager.saveSession(it.email)
        _currentUserEmail.value = it.email
        _uiMessage.value = "Welcome to TODAMENT, ${it.freeFireIgn}!"
      }.onFailure {
        _errorMessage.value = it.message ?: "Registration failed"
      }
    }
  }

  fun loginWithGoogle(email: String, displayName: String) {
    viewModelScope.launch {
      _isLoading.value = true
      var user = repository.getUserSync(email) ?: firestoreSyncManager.fetchUserFromCloud(email)
      if (user == null) {
        val cleanIgn = displayName.replace(" ", "_").filter { it.isLetterOrDigit() || it == '_' }.take(12)
        val generatedIgn = if (cleanIgn.length >= 3) cleanIgn else "PLAYER_${(1000..9999).random()}"
        val generatedUid = (1000000000L..9999999999L).random().toString()
        val regResult = repository.registerUser(
          email = email,
          fullName = displayName,
          phone = "",
          ffUid = generatedUid,
          ffIgn = generatedIgn,
          password = "GoogleAuthUser"
        )
        user = regResult.getOrNull()
      }
      _isLoading.value = false
      if (user != null) {
        sessionManager.saveSession(user.email)
        _currentUserEmail.value = user.email
        _uiMessage.value = "Signed in as ${user.freeFireIgn}"
      } else {
        _errorMessage.value = "Failed to sign in with Google"
      }
    }
  }

  fun switchUser(email: String) {
    sessionManager.saveSession(email)
    _currentUserEmail.value = email
    _uiMessage.value = "Switched to $email"
  }

  fun logout() {
    sessionManager.clearSession()
    _currentUserEmail.value = null
    _uiMessage.value = "Logged out successfully"
  }

  override fun onCleared() {
    super.onCleared()
    firestoreSyncManager.stopSync()
  }

  // --- Tournament Registration ---
  fun registerForTournament(
    tournamentId: String,
    teamName: String,
    teammates: List<Pair<String, String>>,
    onSuccess: () -> Unit
  ) {
    val email = _currentUserEmail.value ?: return
    viewModelScope.launch {
      _isLoading.value = true
      val result = repository.registerForTournament(tournamentId, email, teamName, teammates)
      _isLoading.value = false
      result.onSuccess {
        _uiMessage.value = "Successfully registered! Slot reserved."
        onSuccess()
      }.onFailure {
        _errorMessage.value = it.message ?: "Registration failed"
      }
    }
  }

  // --- Wallet UPI Deposits & Withdrawals ---
  fun submitDeposit(amount: Double, utr: String, screenshotUri: String, onSuccess: () -> Unit) {
    val email = _currentUserEmail.value ?: return
    viewModelScope.launch {
      _isLoading.value = true
      val result = repository.submitDepositRequest(email, amount, utr, screenshotUri)
      _isLoading.value = false
      result.onSuccess {
        _uiMessage.value = "Deposit of ₹${amount.toInt()} submitted for verification!"
        onSuccess()
      }.onFailure {
        _errorMessage.value = it.message ?: "Failed to submit deposit"
      }
    }
  }

  fun submitWithdrawal(amount: Double, upiId: String, accountHolderName: String, onSuccess: () -> Unit) {
    val email = _currentUserEmail.value ?: return
    viewModelScope.launch {
      _isLoading.value = true
      val result = repository.submitWithdrawalRequest(email, amount, upiId, accountHolderName)
      _isLoading.value = false
      result.onSuccess {
        _uiMessage.value = "Withdrawal request of ₹${amount.toInt()} initiated! Funds reserved."
        onSuccess()
      }.onFailure {
        _errorMessage.value = it.message ?: "Withdrawal failed"
      }
    }
  }

  // --- Admin Match Operations ---
  fun createMatch(tournament: Tournament, onSuccess: () -> Unit) {
    viewModelScope.launch {
      repository.createTournament(tournament)
      _uiMessage.value = "Tournament '${tournament.title}' created!"
      onSuccess()
    }
  }

  fun updateMatch(tournament: Tournament, onSuccess: () -> Unit) {
    viewModelScope.launch {
      repository.updateTournament(tournament)
      _uiMessage.value = "Tournament updated successfully!"
      onSuccess()
    }
  }

  fun cancelMatchAndRefund(tournamentId: String) {
    viewModelScope.launch {
      _isLoading.value = true
      repository.cancelTournamentAndRefund(tournamentId)
      _isLoading.value = false
      _uiMessage.value = "Match cancelled. Entry fees refunded to all players!"
    }
  }

  fun updateRoomCredentials(tournamentId: String, roomId: String, roomPass: String, isVisible: Boolean) {
    viewModelScope.launch {
      repository.updateRoomCredentials(tournamentId, roomId, roomPass, isVisible)
      _uiMessage.value = "Room credentials updated and broadcasted!"
    }
  }

  fun distributePrizes(tournamentId: String, results: List<Registration>, onSuccess: () -> Unit) {
    viewModelScope.launch {
      _isLoading.value = true
      repository.distributeTournamentPrizes(tournamentId, results)
      _isLoading.value = false
      _uiMessage.value = "Prizes distributed & referral bonuses credited!"
      onSuccess()
    }
  }

  fun awardCustomPrize(
    userEmail: String,
    tournamentId: String,
    tournamentTitle: String,
    prizeAmount: Double,
    reason: String,
    onSuccess: () -> Unit
  ) {
    viewModelScope.launch {
      _isLoading.value = true
      val result = repository.awardCustomPrizeToUser(userEmail, tournamentId, tournamentTitle, prizeAmount, reason)
      _isLoading.value = false
      result.onSuccess {
        _uiMessage.value = "₹${prizeAmount.toInt()} credited to $userEmail!"
        onSuccess()
      }.onFailure {
        _errorMessage.value = it.message ?: "Failed to award prize"
      }
    }
  }

  // --- Admin Deposit & Withdrawal Reviews ---
  fun approveDeposit(requestId: String) {
    viewModelScope.launch {
      repository.approveDepositRequest(requestId)
      _uiMessage.value = "Deposit approved and credited to player wallet!"
    }
  }

  fun rejectDeposit(requestId: String, reason: String) {
    viewModelScope.launch {
      repository.rejectDepositRequest(requestId, reason)
      _uiMessage.value = "Deposit rejected."
    }
  }

  fun markWithdrawalPaid(requestId: String, payoutRef: String) {
    viewModelScope.launch {
      repository.markWithdrawalPaid(requestId, payoutRef)
      _uiMessage.value = "Withdrawal marked as Paid! Payout Ref: $payoutRef"
    }
  }

  fun rejectWithdrawal(requestId: String, reason: String) {
    viewModelScope.launch {
      repository.rejectWithdrawalRequest(requestId, reason)
      _uiMessage.value = "Withdrawal rejected. Reserved funds refunded to player."
    }
  }

  fun adjustUserBalance(userEmail: String, amountDelta: Double, reason: String) {
    viewModelScope.launch {
      _isLoading.value = true
      val res = repository.adminAdjustUserBalance(userEmail, amountDelta, reason)
      _isLoading.value = false
      res.onSuccess {
        val action = if (amountDelta >= 0) "credited" else "deducted"
        _uiMessage.value = "Successfully $action ₹${kotlin.math.abs(amountDelta)} for $userEmail"
      }.onFailure {
        _errorMessage.value = it.message ?: "Failed to adjust user balance"
      }
    }
  }

  // --- Admin App Settings & Banners ---
  fun saveSettings(settings: AppSettings) {
    viewModelScope.launch {
      repository.updateAppSettings(settings)
      _uiMessage.value = "App & UPI settings saved!"
    }
  }

  fun addBanner(banner: PromotionalBanner) {
    viewModelScope.launch {
      repository.insertBanner(banner)
      _uiMessage.value = "Banner added successfully!"
    }
  }

  fun deleteBanner(banner: PromotionalBanner) {
    viewModelScope.launch {
      repository.deleteBanner(banner)
      _uiMessage.value = "Banner removed."
    }
  }

  // --- Backup & Restore ---
  fun exportBackup(onExportReady: (String) -> Unit) {
    viewModelScope.launch {
      _isLoading.value = true
      val json = repository.exportBackupJson()
      _isLoading.value = false
      onExportReady(json)
      _uiMessage.value = "Full system backup generated successfully!"
    }
  }

  fun restoreBackup(jsonString: String) {
    viewModelScope.launch {
      _isLoading.value = true
      val result = repository.restoreBackupJson(jsonString)
      _isLoading.value = false
      result.onSuccess { count ->
        _uiMessage.value = "Backup restored successfully! ($count records synced)"
      }.onFailure {
        _errorMessage.value = "Restore failed: ${it.message}"
      }
    }
  }
}
