package com.example.data.ai

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.content
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

private const val TAG = "TodamentAiCoach"

enum class AiModelOption(val modelName: String, val displayName: String, val description: String) {
  FLASH_GENERAL("gemini-3.8-flash", "Gemini 3.8 Flash", "Balanced & Versatile (Default)"),
  LITE_FAST("gemini-3.1-flash-lite", "Gemini 3.1 Flash Lite", "Ultra Fast Responses"),
  ARGON_COMPLEX("gemini-4-argon", "Gemini 4 Argon", "Deep Tactical Analysis")
}

class TodamentAiCoachService {

  private val systemPrompt = """
    You are the official TODAMENT Esports AI Coach & Support Specialist for the TODAMENT Android Application.
    Your roles and capabilities:
    1. Free Fire Strategy & Tactical Coach: You provide expert advice on Free Fire gameplay, loadouts, weapon combinations (e.g. M1887 + MP40, Woodpecker, AWM), character ability combinations (e.g. Alok, Homer, Hayato, Kelly), and tactical rotations for maps: Bermuda, Purgatory, Kalahari, NexTerra, and Clash Squad.
    2. Tournament & Scrim Rules Guide: You explain TODAMENT tournament formats (Solo, Duo, Squad, Clash Squad), entry fee requirements, prize pool distributions (1st, 2nd, 3rd, and per-kill bonuses), custom room rules (mobile-only, fair play, gun attributes), and how room credentials (Room ID and Password) are delivered.
    3. Wallet, Deposits & Withdrawals: Explain how players deposit funds via UPI with 12-digit UTR reference numbers, instant withdrawals to any verified UPI ID, and automatic wallet refunds if an organizer cancels a tournament.
    
    Style & Tone:
    - Energetic, encouraging, and esports-focused.
    - Use popular gaming terminology (Booyah, zone rotation, rush, clutch, IGL, flank).
    - Keep answers clear, structured with bullet points and bold highlights.
  """.trimIndent()

  private fun getGenerativeModel(modelOption: AiModelOption) = Firebase.ai.generativeModel(
    modelName = modelOption.modelName,
    systemInstruction = content { text(systemPrompt) }
  )

  /**
   * Multi-turn chat message streaming with 60-second coroutine timeout.
   */
  fun sendChatStream(
    history: List<Pair<String, Boolean>>, // (text, isUser)
    userMessage: String,
    modelOption: AiModelOption = AiModelOption.FLASH_GENERAL
  ): Flow<String> = flow {
    val model = getGenerativeModel(modelOption)

    // Build chat history
    val chatHistory = mutableListOf<Content>()
    for ((msgText, isUser) in history) {
      if (isUser) {
        chatHistory.add(content("user") { text(msgText) })
      } else {
        chatHistory.add(content("model") { text(msgText) })
      }
    }

    val chat = model.startChat(history = chatHistory)

    try {
      withTimeout(60_000L) {
        chat.sendMessageStream(userMessage).collect { chunk ->
          val chunkText = chunk.text.orEmpty()
          if (chunkText.isNotEmpty()) {
            emit(chunkText)
          }
        }
      }
    } catch (e: TimeoutCancellationException) {
      Log.e(TAG, "AI streaming response timed out after 60s", e)
      throw Exception("AI response timed out. Please try sending a shorter prompt.")
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      Log.e(TAG, "Error generating AI stream: ${e.message}", e)
      throw e
    }
  }

  /**
   * Single-turn quick generation with 60s timeout.
   */
  suspend fun generateQuickAdvice(
    prompt: String,
    modelOption: AiModelOption = AiModelOption.LITE_FAST
  ): String = withContext(Dispatchers.IO) {
    val model = getGenerativeModel(modelOption)
    try {
      withTimeout(60_000L) {
        val response = model.generateContent(prompt)
        response.text ?: "No advice generated."
      }
    } catch (e: TimeoutCancellationException) {
      Log.e(TAG, "Quick advice timed out", e)
      "Request timed out. Please try again."
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      Log.e(TAG, "Quick advice error: ${e.message}", e)
      throw e
    }
  }
}
