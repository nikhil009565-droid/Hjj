package com.example.data.firestore

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.model.AppSettings
import com.example.data.model.MatchFormat
import com.example.data.model.MatchStatus
import com.example.data.model.Tournament
import com.example.data.model.User
import com.example.data.model.WalletTransaction
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class FirestoreSyncManager(
  private val context: Context,
  private val database: AppDatabase
) {
  private val db: FirebaseFirestore by lazy {
    FirebaseFirestore.getInstance(context.applicationContext.getString(R.string.firestore_database_id))
  }

  private var tournamentsListener: ListenerRegistration? = null
  private var settingsListener: ListenerRegistration? = null
  private var usersListener: ListenerRegistration? = null

  companion object {
    private const val TAG = "FirestoreSync"

    fun emailToDocId(email: String): String {
      return email.lowercase().trim().replace(".", "_").replace("@", "_at_")
    }
  }

  fun startRealtimeSync(scope: CoroutineScope) {
    try {
      // 1. Sync global app settings in real-time
      val settingsDoc = db.collection("app_settings").document("global_config")
      settingsListener = settingsDoc.addSnapshotListener { snapshot, error ->
        if (error != null) {
          handleFirestoreError(error, OperationType.GET, settingsDoc.path)
          return@addSnapshotListener
        }
        if (snapshot != null && snapshot.exists()) {
          val data = snapshot.data ?: return@addSnapshotListener
          scope.launch(Dispatchers.IO) {
            val existing = database.appConfigDao().getSettingsSync() ?: AppSettings()
            val updated = existing.copy(
              adminUpiId = data["adminUpiId"] as? String ?: existing.adminUpiId,
              adminPayeeName = data["adminPayeeName"] as? String ?: existing.adminPayeeName,
              telegramHelpUrl = data["telegramHelpUrl"] as? String ?: existing.telegramHelpUrl,
              qrCodeImageUri = data["qrCodeImageUri"] as? String ?: existing.qrCodeImageUri,
              supportContact = data["supportContact"] as? String ?: existing.supportContact,
              announcementNotice = data["announcementNotice"] as? String ?: existing.announcementNotice,
              minDepositAmount = (data["minDepositAmount"] as? Number)?.toDouble() ?: existing.minDepositAmount,
              minWithdrawalAmount = (data["minWithdrawalAmount"] as? Number)?.toDouble() ?: existing.minWithdrawalAmount
            )
            database.appConfigDao().saveSettings(updated)
            Log.d(TAG, "Synced AppSettings from Firestore successfully")
          }
        }
      }

      // 2. Sync tournaments in real-time
      val tournamentsCol = db.collection("tournaments")
      tournamentsListener = tournamentsCol.addSnapshotListener { snapshots, error ->
        if (error != null) {
          handleFirestoreError(error, OperationType.LIST, tournamentsCol.path)
          return@addSnapshotListener
        }
        if (snapshots != null) {
          scope.launch(Dispatchers.IO) {
            // 1. Handle deleted tournaments
            for (change in snapshots.documentChanges) {
              if (change.type == com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                database.tournamentDao().deleteTournamentById(change.document.id)
                Log.d(TAG, "Removed deleted tournament ${change.document.id} from local Room cache")
              }
            }
            // 2. Insert or update existing tournaments
            for (doc in snapshots.documents) {
              val data = doc.data ?: continue
              val id = doc.id
              val title = data["title"] as? String ?: continue
              val mapName = data["mapName"] as? String ?: "Bermuda"
              val formatStr = data["format"] as? String ?: "SOLO"
              val format = try {
                MatchFormat.valueOf(formatStr)
              } catch (e: Exception) {
                MatchFormat.SOLO
              }
              val statusStr = data["status"] as? String ?: "OPEN"
              val status = try {
                MatchStatus.valueOf(statusStr)
              } catch (e: Exception) {
                MatchStatus.OPEN
              }
              val entryFee = (data["entryFee"] as? Number)?.toDouble() ?: 0.0
              val totalPrizePool = (data["totalPrizePool"] as? Number)?.toDouble() ?: 0.0
              val firstPrize = (data["firstPrize"] as? Number)?.toDouble() ?: 0.0
              val secondPrize = (data["secondPrize"] as? Number)?.toDouble() ?: 0.0
              val thirdPrize = (data["thirdPrize"] as? Number)?.toDouble() ?: 0.0
              val perKillBonus = (data["perKillBonus"] as? Number)?.toDouble() ?: 0.0
              val matchDate = data["matchDate"] as? String ?: ""
              val startTime = data["startTime"] as? String ?: ""
              val regClose = data["registrationClosingTime"] as? String ?: ""
              val matchTimestamp = (data["matchTimestamp"] as? Number)?.toLong() ?: System.currentTimeMillis()
              val totalSlots = (data["totalSlots"] as? Number)?.toInt() ?: 48
              val filledSlots = (data["filledSlots"] as? Number)?.toInt() ?: 0
              val customRules = data["customRules"] as? String ?: ""
              val roomId = data["roomId"] as? String ?: ""
              val roomPassword = data["roomPassword"] as? String ?: ""
              val isRoomVisible = data["isRoomVisible"] as? Boolean ?: false

              val tourn = Tournament(
                id = id,
                title = title,
                mapName = mapName,
                format = format,
                entryFee = entryFee,
                totalPrizePool = totalPrizePool,
                firstPrize = firstPrize,
                secondPrize = secondPrize,
                thirdPrize = thirdPrize,
                perKillBonus = perKillBonus,
                matchDate = matchDate,
                startTime = startTime,
                registrationClosingTime = regClose,
                matchTimestamp = matchTimestamp,
                totalSlots = totalSlots,
                filledSlots = filledSlots,
                status = status,
                customRules = customRules,
                roomId = roomId,
                roomPassword = roomPassword,
                isRoomVisible = isRoomVisible
              )
              database.tournamentDao().insertTournament(tourn)
            }
            Log.d(TAG, "Synced ${snapshots.size()} tournaments from Firestore")
          }
        }
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error starting realtime sync", e)
    }
  }

  suspend fun syncUserToCloud(user: User) = withContext(Dispatchers.IO) {
    try {
      val docId = emailToDocId(user.email)
      val docRef = db.collection("users").document(docId)
      val data = hashMapOf<String, Any>(
        "userId" to docId,
        "email" to user.email,
        "fullName" to user.fullName,
        "phoneNumber" to user.phoneNumber,
        "freeFireUid" to user.freeFireUid,
        "freeFireIgn" to user.freeFireIgn,
        "referralCode" to user.referralCode,
        "referredByCode" to user.referredByCode,
        "password" to user.password,
        "walletBalance" to user.walletBalance,
        "totalDeposited" to user.totalDeposited,
        "totalWinnings" to user.totalWinnings,
        "totalWithdrawn" to user.totalWithdrawn,
        "reservedForWithdrawal" to user.reservedForWithdrawal,
        "isAdmin" to user.isAdmin,
        "createdAt" to user.createdAt,
        "updatedAt" to System.currentTimeMillis()
      )
      docRef.set(data, SetOptions.merge()).await()
      Log.d(TAG, "Successfully synced user ${user.email} to Firestore")
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "users/${emailToDocId(user.email)}")
      Log.e(TAG, "Failed to sync user to cloud", e)
    }
  }

  suspend fun fetchUserFromCloud(email: String): User? = withContext(Dispatchers.IO) {
    try {
      val docId = emailToDocId(email)
      val docRef = db.collection("users").document(docId)
      val snapshot = docRef.get().await()
      if (snapshot.exists()) {
        val data = snapshot.data ?: return@withContext null
        val user = User(
          email = data["email"] as? String ?: email,
          fullName = data["fullName"] as? String ?: "",
          phoneNumber = data["phoneNumber"] as? String ?: "",
          freeFireUid = data["freeFireUid"] as? String ?: "",
          freeFireIgn = data["freeFireIgn"] as? String ?: "",
          referralCode = data["referralCode"] as? String ?: "",
          referredByCode = data["referredByCode"] as? String ?: "",
          password = data["password"] as? String ?: "",
          walletBalance = (data["walletBalance"] as? Number)?.toDouble() ?: 0.0,
          totalDeposited = (data["totalDeposited"] as? Number)?.toDouble() ?: 0.0,
          totalWinnings = (data["totalWinnings"] as? Number)?.toDouble() ?: 0.0,
          totalWithdrawn = (data["totalWithdrawn"] as? Number)?.toDouble() ?: 0.0,
          reservedForWithdrawal = (data["reservedForWithdrawal"] as? Number)?.toDouble() ?: 0.0,
          isAdmin = data["isAdmin"] as? Boolean ?: false,
          createdAt = (data["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
        )
        // Cache to Room
        database.userDao().insertUser(user)
        return@withContext user
      }
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.GET, "users/${emailToDocId(email)}")
      Log.e(TAG, "Failed to fetch user from cloud", e)
    }
    null
  }

  suspend fun syncTournamentToCloud(t: Tournament) = withContext(Dispatchers.IO) {
    try {
      val docRef = db.collection("tournaments").document(t.id)
      val data = hashMapOf<String, Any>(
        "id" to t.id,
        "title" to t.title,
        "mapName" to t.mapName,
        "format" to t.format.name,
        "entryFee" to t.entryFee,
        "totalPrizePool" to t.totalPrizePool,
        "firstPrize" to t.firstPrize,
        "secondPrize" to t.secondPrize,
        "thirdPrize" to t.thirdPrize,
        "perKillBonus" to t.perKillBonus,
        "matchDate" to t.matchDate,
        "startTime" to t.startTime,
        "registrationClosingTime" to t.registrationClosingTime,
        "matchTimestamp" to t.matchTimestamp,
        "totalSlots" to t.totalSlots,
        "filledSlots" to t.filledSlots,
        "status" to t.status.name,
        "customRules" to t.customRules,
        "roomId" to t.roomId,
        "roomPassword" to t.roomPassword,
        "isRoomVisible" to t.isRoomVisible,
        "updatedAt" to System.currentTimeMillis()
      )
      docRef.set(data, SetOptions.merge()).await()
      Log.d(TAG, "Successfully synced tournament ${t.id} to Firestore")
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "tournaments/${t.id}")
      Log.e(TAG, "Failed to sync tournament to cloud", e)
    }
  }

  suspend fun deleteTournamentFromCloud(tournamentId: String) = withContext(Dispatchers.IO) {
    try {
      db.collection("tournaments").document(tournamentId).delete().await()
      Log.d(TAG, "Successfully deleted tournament $tournamentId from Firestore")
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "tournaments/$tournamentId")
      Log.e(TAG, "Failed to delete tournament from cloud", e)
    }
  }

  suspend fun syncAppSettingsToCloud(settings: AppSettings) = withContext(Dispatchers.IO) {
    try {
      val docRef = db.collection("app_settings").document("global_config")
      val data = hashMapOf<String, Any>(
        "id" to "global_config",
        "adminUpiId" to settings.adminUpiId,
        "adminPayeeName" to settings.adminPayeeName,
        "telegramHelpUrl" to settings.telegramHelpUrl,
        "qrCodeImageUri" to settings.qrCodeImageUri,
        "supportContact" to settings.supportContact,
        "announcementNotice" to settings.announcementNotice,
        "minDepositAmount" to settings.minDepositAmount,
        "minWithdrawalAmount" to settings.minWithdrawalAmount,
        "updatedAt" to System.currentTimeMillis()
      )
      docRef.set(data, SetOptions.merge()).await()
      Log.d(TAG, "Successfully synced AppSettings to Firestore")
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "app_settings/global_config")
      Log.e(TAG, "Failed to sync app settings to cloud", e)
    }
  }

  suspend fun syncTransactionToCloud(tx: WalletTransaction) = withContext(Dispatchers.IO) {
    try {
      val docRef = db.collection("transactions").document(tx.id)
      val data = hashMapOf<String, Any>(
        "id" to tx.id,
        "userId" to emailToDocId(tx.userEmail),
        "userEmail" to tx.userEmail,
        "type" to tx.type.name,
        "amount" to tx.amount,
        "title" to tx.title,
        "description" to tx.description,
        "referenceId" to tx.referenceId,
        "timestamp" to tx.timestamp,
        "updatedAt" to System.currentTimeMillis()
      )
      docRef.set(data, SetOptions.merge()).await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "transactions/${tx.id}")
      Log.e(TAG, "Failed to sync transaction to cloud", e)
    }
  }

  fun stopSync() {
    tournamentsListener?.remove()
    tournamentsListener = null
    settingsListener?.remove()
    settingsListener = null
    usersListener?.remove()
    usersListener = null
  }
}
