package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.User
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
  @Query("SELECT * FROM users WHERE LOWER(email) = LOWER(:email) LIMIT 1")
  fun getUser(email: String): Flow<User?>

  @Query("SELECT * FROM users WHERE LOWER(email) = LOWER(:email) LIMIT 1")
  suspend fun getUserSync(email: String): User?

  @Query("SELECT * FROM users WHERE phoneNumber = :phone LIMIT 1")
  suspend fun getUserByPhone(phone: String): User?

  @Query("SELECT * FROM users WHERE referralCode = :code LIMIT 1")
  suspend fun getUserByReferralCode(code: String): User?

  @Query("SELECT * FROM users WHERE referredByCode = :referralCode")
  fun getReferredUsers(referralCode: String): Flow<List<User>>

  @Query("SELECT * FROM users ORDER BY createdAt DESC")
  fun getAllUsers(): Flow<List<User>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertUser(user: User)

  @Update
  suspend fun updateUser(user: User)

  @Query("DELETE FROM users WHERE email = :email")
  suspend fun deleteUserByEmail(email: String)
}
