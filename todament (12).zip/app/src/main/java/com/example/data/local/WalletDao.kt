package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.DepositRequest
import com.example.data.model.WalletTransaction
import com.example.data.model.WithdrawalRequest
import kotlinx.coroutines.flow.Flow

@Dao
interface WalletDao {
  // Transactions
  @Query("SELECT * FROM wallet_transactions WHERE userEmail = :userEmail ORDER BY timestamp DESC")
  fun getTransactionsForUser(userEmail: String): Flow<List<WalletTransaction>>

  @Query("SELECT * FROM wallet_transactions ORDER BY timestamp DESC")
  fun getAllTransactions(): Flow<List<WalletTransaction>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTransaction(transaction: WalletTransaction)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTransactions(transactions: List<WalletTransaction>)

  @Query("DELETE FROM wallet_transactions WHERE userEmail = :userEmail")
  suspend fun deleteTransactionsByEmail(userEmail: String)

  // Deposit Requests
  @Query("SELECT * FROM deposit_requests ORDER BY createdAt DESC")
  fun getAllDepositRequests(): Flow<List<DepositRequest>>

  @Query("SELECT * FROM deposit_requests WHERE userEmail = :userEmail ORDER BY createdAt DESC")
  fun getDepositRequestsForUser(userEmail: String): Flow<List<DepositRequest>>

  @Query("SELECT * FROM deposit_requests WHERE id = :id LIMIT 1")
  suspend fun getDepositRequestById(id: String): DepositRequest?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertDepositRequest(request: DepositRequest)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertDepositRequests(requests: List<DepositRequest>)

  @Update
  suspend fun updateDepositRequest(request: DepositRequest)

  // Withdrawal Requests
  @Query("SELECT * FROM withdrawal_requests ORDER BY createdAt DESC")
  fun getAllWithdrawalRequests(): Flow<List<WithdrawalRequest>>

  @Query("SELECT * FROM withdrawal_requests WHERE userEmail = :userEmail ORDER BY createdAt DESC")
  fun getWithdrawalRequestsForUser(userEmail: String): Flow<List<WithdrawalRequest>>

  @Query("SELECT * FROM withdrawal_requests WHERE id = :id LIMIT 1")
  suspend fun getWithdrawalRequestById(id: String): WithdrawalRequest?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertWithdrawalRequest(request: WithdrawalRequest)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertWithdrawalRequests(requests: List<WithdrawalRequest>)

  @Update
  suspend fun updateWithdrawalRequest(request: WithdrawalRequest)
}
