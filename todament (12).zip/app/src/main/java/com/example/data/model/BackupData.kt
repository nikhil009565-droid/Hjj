package com.example.data.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class TodamentBackup(
  val version: Int = 1,
  val exportTimestamp: Long = System.currentTimeMillis(),
  val users: List<UserBackupItem> = emptyList(),
  val tournaments: List<TournamentBackupItem> = emptyList(),
  val registrations: List<RegistrationBackupItem> = emptyList(),
  val transactions: List<TransactionBackupItem> = emptyList(),
  val depositRequests: List<DepositBackupItem> = emptyList(),
  val withdrawalRequests: List<WithdrawalBackupItem> = emptyList()
)

@JsonClass(generateAdapter = true)
data class UserBackupItem(
  val email: String,
  val fullName: String,
  val phoneNumber: String,
  val freeFireUid: String,
  val freeFireIgn: String,
  val referralCode: String,
  val referredByCode: String,
  val password: String = "",
  val walletBalance: Double,
  val totalDeposited: Double,
  val totalWinnings: Double,
  val totalWithdrawn: Double,
  val reservedForWithdrawal: Double,
  val isAdmin: Boolean,
  val createdAt: Long
)

@JsonClass(generateAdapter = true)
data class TournamentBackupItem(
  val id: String,
  val title: String,
  val mapName: String,
  val format: String,
  val entryFee: Double,
  val totalPrizePool: Double,
  val firstPrize: Double,
  val secondPrize: Double,
  val thirdPrize: Double,
  val perKillBonus: Double,
  val matchDate: String,
  val startTime: String,
  val registrationClosingTime: String,
  val matchTimestamp: Long,
  val totalSlots: Int,
  val filledSlots: Int,
  val status: String,
  val customRules: String,
  val roomId: String,
  val roomPassword: String,
  val isRoomVisible: Boolean
)

@JsonClass(generateAdapter = true)
data class RegistrationBackupItem(
  val id: String,
  val tournamentId: String,
  val userEmail: String,
  val teamName: String,
  val playerIgn: String,
  val playerUid: String,
  val teammatesJson: String,
  val entryFeePaid: Double,
  val registeredAt: Long,
  val kills: Int,
  val placementRank: Int,
  val prizeWon: Double
)

@JsonClass(generateAdapter = true)
data class TransactionBackupItem(
  val id: String,
  val userEmail: String,
  val type: String,
  val amount: Double,
  val title: String,
  val description: String,
  val referenceId: String,
  val timestamp: Long
)

@JsonClass(generateAdapter = true)
data class DepositBackupItem(
  val id: String,
  val userEmail: String,
  val userName: String,
  val userPhone: String,
  val amount: Double,
  val utrNumber: String,
  val screenshotUri: String,
  val status: String,
  val adminComment: String,
  val createdAt: Long,
  val resolvedAt: Long
)

@JsonClass(generateAdapter = true)
data class WithdrawalBackupItem(
  val id: String,
  val userEmail: String,
  val userName: String,
  val amount: Double,
  val upiId: String,
  val accountHolderName: String,
  val status: String,
  val payoutReference: String,
  val rejectReason: String,
  val createdAt: Long,
  val resolvedAt: Long
)
