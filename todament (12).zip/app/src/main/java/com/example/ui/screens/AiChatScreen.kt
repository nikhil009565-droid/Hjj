package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.ai.AiModelOption
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CarbonBackground
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonCard
import com.example.ui.theme.CarbonCardElevated
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AiChatViewModel
import com.example.ui.viewmodel.ChatMessage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AiChatScreen(
  viewModel: AiChatViewModel = viewModel(),
  onNavigateBack: () -> Unit
) {
  val messages by viewModel.messages.collectAsState()
  val selectedModel by viewModel.selectedModel.collectAsState()
  val isGenerating by viewModel.isGenerating.collectAsState()

  var inputText by remember { mutableStateOf("") }
  var showModelMenu by remember { mutableStateOf(false) }

  val listState = rememberLazyListState()

  // Auto-scroll to bottom on new message
  LaunchedEffect(messages.size, messages.lastOrNull()?.text?.length) {
    if (messages.isNotEmpty()) {
      listState.animateScrollToItem(messages.size - 1)
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CarbonBackground)
      .imePadding()
  ) {
    // Top Bar Header
    Surface(
      color = CarbonSurface,
      tonalElevation = 6.dp,
      modifier = Modifier
        .fillMaxWidth()
        .border(1.dp, CarbonBorder)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            onClick = onNavigateBack,
            modifier = Modifier.testTag("btn_ai_chat_back")
          ) {
            Icon(
              Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = TextPrimary
            )
          }

          Box(
            modifier = Modifier
              .size(38.dp)
              .clip(CircleShape)
              .background(Brush.linearGradient(listOf(EmeraldNeon, NeonCyan))),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              Icons.Default.AutoAwesome,
              contentDescription = null,
              tint = CarbonBackground,
              modifier = Modifier.size(22.dp)
            )
          }

          Spacer(modifier = Modifier.width(10.dp))

          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "TODAMENT AI COACH",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Black,
                color = TextPrimary,
                letterSpacing = 0.5.sp
              )
              Spacer(modifier = Modifier.width(6.dp))
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(4.dp))
                  .background(EmeraldDark)
                  .padding(horizontal = 5.dp, vertical = 2.dp)
              ) {
                Text(
                  text = "GEMINI",
                  style = MaterialTheme.typography.labelSmall,
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Bold,
                  color = EmeraldNeon
                )
              }
            }
            Text(
              text = selectedModel.displayName,
              style = MaterialTheme.typography.bodySmall,
              fontSize = 11.sp,
              color = NeonCyan
            )
          }
        }

        // Actions: Model Picker & Clear
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            onClick = { viewModel.clearHistory() },
            modifier = Modifier.testTag("btn_clear_chat")
          ) {
            Icon(
              Icons.Default.DeleteSweep,
              contentDescription = "Clear Chat",
              tint = TextSecondary,
              modifier = Modifier.size(22.dp)
            )
          }

          Box {
            IconButton(
              onClick = { showModelMenu = true },
              modifier = Modifier.testTag("btn_select_ai_model")
            ) {
              Icon(
                Icons.Default.MoreVert,
                contentDescription = "Change Model",
                tint = TextPrimary
              )
            }

            DropdownMenu(
              expanded = showModelMenu,
              onDismissRequest = { showModelMenu = false },
              modifier = Modifier.background(CarbonCardElevated)
            ) {
              AiModelOption.entries.forEach { option ->
                DropdownMenuItem(
                  text = {
                    Column {
                      Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                          imageVector = when (option) {
                            AiModelOption.FLASH_GENERAL -> Icons.Default.AutoAwesome
                            AiModelOption.LITE_FAST -> Icons.Default.Bolt
                            AiModelOption.ARGON_COMPLEX -> Icons.Default.Psychology
                          },
                          contentDescription = null,
                          tint = if (selectedModel == option) EmeraldNeon else TextSecondary,
                          modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                          text = option.displayName,
                          fontWeight = if (selectedModel == option) FontWeight.Bold else FontWeight.Normal,
                          color = if (selectedModel == option) EmeraldNeon else TextPrimary
                        )
                      }
                      Text(
                        text = option.description,
                        fontSize = 11.sp,
                        color = TextMuted,
                        modifier = Modifier.padding(start = 24.dp)
                      )
                    }
                  },
                  onClick = {
                    viewModel.setModel(option)
                    showModelMenu = false
                  }
                )
              }
            }
          }
        }
      }
    }

    // Chat Message Thread
    LazyColumn(
      state = listState,
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth(),
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      items(messages, key = { it.id }) { msg ->
        ChatMessageBubble(message = msg)
      }
    }

    // Suggested Quick Action Prompts
    AnimatedVisibility(visible = !isGenerating && messages.size <= 3) {
      LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(viewModel.suggestedPrompts) { prompt ->
          Surface(
            onClick = {
              viewModel.sendMessage(prompt)
            },
            shape = RoundedCornerShape(16.dp),
            color = CarbonCard,
            border = CardDefaults.outlinedCardBorder().copy(
              brush = Brush.horizontalGradient(listOf(CarbonBorder, EmeraldDark.copy(alpha = 0.5f)))
            ),
            modifier = Modifier.testTag("chip_prompt_${prompt.take(10)}")
          ) {
            Text(
              text = prompt,
              fontSize = 12.sp,
              color = TextPrimary,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
          }
        }
      }
    }

    // Input Bar
    Surface(
      color = CarbonSurface,
      tonalElevation = 8.dp,
      modifier = Modifier
        .fillMaxWidth()
        .border(1.dp, CarbonBorder)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
          value = inputText,
          onValueChange = { inputText = it },
          placeholder = { Text("Ask coach anything about FF, rules, wallet...", fontSize = 13.sp, color = TextMuted) },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = EmeraldNeon,
            unfocusedBorderColor = CarbonBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            cursorColor = EmeraldNeon
          ),
          shape = RoundedCornerShape(24.dp),
          maxLines = 4,
          modifier = Modifier
            .weight(1f)
            .testTag("input_ai_chat_message")
        )

        Spacer(modifier = Modifier.width(8.dp))

        Box(
          modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(
              if (inputText.isNotBlank() && !isGenerating)
                Brush.linearGradient(listOf(EmeraldNeon, NeonCyan))
              else
                Brush.linearGradient(listOf(CarbonCardElevated, CarbonCardElevated))
            )
            .clickable(enabled = inputText.isNotBlank() && !isGenerating) {
              val textToSend = inputText
              inputText = ""
              viewModel.sendMessage(textToSend)
            }
            .testTag("btn_send_ai_chat"),
          contentAlignment = Alignment.Center
        ) {
          if (isGenerating) {
            CircularProgressIndicator(
              modifier = Modifier.size(20.dp),
              color = EmeraldNeon,
              strokeWidth = 2.dp
            )
          } else {
            Icon(
              Icons.AutoMirrored.Filled.Send,
              contentDescription = "Send",
              tint = if (inputText.isNotBlank()) CarbonBackground else TextMuted,
              modifier = Modifier.size(20.dp)
            )
          }
        }
      }
    }
  }
}

@Composable
fun ChatMessageBubble(message: ChatMessage) {
  val isUser = message.isFromUser
  val timeFormat = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
  val formattedTime = remember(message.timestamp) { timeFormat.format(Date(message.timestamp)) }

  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
    verticalAlignment = Alignment.Bottom
  ) {
    if (!isUser) {
      Box(
        modifier = Modifier
          .size(28.dp)
          .clip(CircleShape)
          .background(EmeraldDark),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          Icons.Default.AutoAwesome,
          contentDescription = null,
          tint = EmeraldNeon,
          modifier = Modifier.size(16.dp)
        )
      }
      Spacer(modifier = Modifier.width(6.dp))
    }

    Box(
      modifier = Modifier
        .widthIn(max = 300.dp)
        .clip(
          RoundedCornerShape(
            topStart = 16.dp,
            topEnd = 16.dp,
            bottomStart = if (isUser) 16.dp else 4.dp,
            bottomEnd = if (isUser) 4.dp else 16.dp
          )
        )
        .background(
          if (isUser)
            Brush.linearGradient(listOf(EmeraldNeon, NeonCyan))
          else
            Brush.linearGradient(listOf(CarbonCardElevated, CarbonCardElevated))
        )
        .border(
          width = 1.dp,
          color = if (isUser) Color.Transparent else CarbonBorder,
          shape = RoundedCornerShape(
            topStart = 16.dp,
            topEnd = 16.dp,
            bottomStart = if (isUser) 16.dp else 4.dp,
            bottomEnd = if (isUser) 4.dp else 16.dp
          )
        )
        .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
      Column {
        if (!isUser) {
          Text(
            text = "TODAMENT AI COACH",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Black,
            fontSize = 9.sp,
            color = EmeraldNeon,
            letterSpacing = 0.5.sp
          )
          Spacer(modifier = Modifier.height(3.dp))
        }

        if (message.text.isEmpty() && message.isStreaming) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(
              modifier = Modifier.size(14.dp),
              color = EmeraldNeon,
              strokeWidth = 1.5.dp
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Coach is thinking...",
              style = MaterialTheme.typography.bodySmall,
              color = TextMuted,
              fontSize = 12.sp
            )
          }
        } else {
          Text(
            text = message.text,
            style = MaterialTheme.typography.bodyMedium,
            color = if (isUser) CarbonBackground else TextPrimary,
            fontSize = 13.5.sp,
            lineHeight = 19.sp,
            fontWeight = if (isUser) FontWeight.Medium else FontWeight.Normal
          )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = formattedTime,
          style = MaterialTheme.typography.labelSmall,
          fontSize = 9.sp,
          color = if (isUser) CarbonBackground.copy(alpha = 0.7f) else TextMuted,
          modifier = Modifier.align(Alignment.End)
        )
      }
    }
  }
}
