package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.MatchFormat
import com.example.data.model.MatchStatus
import com.example.data.model.PromotionalBanner
import com.example.data.model.Tournament
import com.example.ui.components.FormatBadge
import com.example.ui.components.MapBadge
import com.example.ui.components.StatusBadge
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CarbonBackground
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonCard
import com.example.ui.theme.CarbonCardElevated
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.TodamentViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
  viewModel: TodamentViewModel,
  onNavigateToTournaments: () -> Unit,
  onNavigateToWallet: () -> Unit,
  onNavigateToRefer: () -> Unit,
  onSelectTournament: (Tournament) -> Unit,
  onNavigateToAiCoach: () -> Unit = {}
) {
  val currentUser by viewModel.currentUser.collectAsState()
  val banners by viewModel.banners.collectAsState()
  val filteredTournaments by viewModel.filteredTournaments.collectAsState()
  val selectedCategory by viewModel.selectedCategory.collectAsState()
  val appSettings by viewModel.appSettings.collectAsState()

  val categories = listOf("All", "Solo", "Duo", "Squad", "Clash Squad")

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(CarbonBackground),
    contentPadding = PaddingValues(bottom = 90.dp)
  ) {
    // 1. TOP PROMOTIONAL BANNER CAROUSEL (Auto-play & Touch-swipe)
    if (banners.isNotEmpty()) {
      item {
        BannerCarousel(
          banners = banners,
          onBannerClick = { banner ->
            when (banner.targetScreen) {
              "refer" -> onNavigateToRefer()
              "wallet" -> onNavigateToWallet()
              "ai_coach" -> onNavigateToAiCoach()
              else -> onNavigateToTournaments()
            }
          }
        )
      }
    }

    // 2. QUICK STATS: WALLET & ONGOING STATUS
    item {
      Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
        QuickStatsCard(
          walletBalance = currentUser?.walletBalance ?: 0.0,
          onDepositClick = onNavigateToWallet
        )

        Spacer(modifier = Modifier.height(10.dp))

        // AI Coach Strategy Card
        Card(
          onClick = onNavigateToAiCoach,
          colors = CardDefaults.cardColors(containerColor = CarbonCard),
          border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(listOf(EmeraldNeon.copy(alpha = 0.5f), NeonCyan.copy(alpha = 0.5f)))
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("card_home_ai_coach")
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(EmeraldNeon, NeonCyan))),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = CarbonBackground,
                modifier = Modifier.size(22.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "TODAMENT AI COACH",
                  fontWeight = FontWeight.Black,
                  fontSize = 13.sp,
                  color = TextPrimary
                )
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(EmeraldDark)
                    .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                  Text(
                    text = "GEMINI 3.8",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldNeon
                  )
                }
              }
              Text(
                text = "Ask pro weapon combos, Bermuda rotations & rules",
                fontSize = 11.sp,
                color = TextSecondary
              )
            }
            Icon(
              Icons.Default.ChevronRight,
              contentDescription = null,
              tint = EmeraldNeon,
              modifier = Modifier.size(20.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Announcement / Scrim Notice Bar
        Card(
          colors = CardDefaults.cardColors(containerColor = CarbonCardElevated),
          border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, EmeraldDark.copy(alpha = 0.5f)))),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(EmeraldNeon)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = appSettings.announcementNotice,
              style = MaterialTheme.typography.bodySmall,
              color = TextSecondary,
              fontSize = 12.sp,
              modifier = Modifier.weight(1f)
            )
          }
        }
      }
    }

    // 3. CATEGORY PILLS / FILTER TABS
    item {
      Column(modifier = Modifier.padding(top = 8.dp)) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "FEATURED SCRIMS",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp,
            color = TextPrimary
          )
          Row(
            modifier = Modifier.clickable { onNavigateToTournaments() },
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(text = "View All", color = NeonCyan, style = MaterialTheme.typography.bodySmall)
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyRow(
          contentPadding = PaddingValues(horizontal = 16.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          items(categories) { category ->
            val isSelected = selectedCategory == category
            Surface(
              onClick = { viewModel.selectCategory(category) },
              shape = RoundedCornerShape(20.dp),
              color = if (isSelected) EmeraldNeon else CarbonCard,
              border = if (!isSelected) CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, CarbonBorder))) else null,
              modifier = Modifier.testTag("filter_chip_$category")
            ) {
              Text(
                text = category,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) CarbonBackground else TextSecondary,
                fontSize = 12.sp
              )
            }
          }
        }
      }
    }

    // 4. CLEAN MATCH CARDS (STRICTLY TEXT & FORMAT ONLY, NO THUMBNAILS)
    if (filteredTournaments.isEmpty()) {
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "No matches available in this format right now.",
            color = TextMuted,
            style = MaterialTheme.typography.bodyMedium
          )
        }
      }
    } else {
      items(filteredTournaments) { tournament ->
        MatchCardItem(
          tournament = tournament,
          onCardClick = { onSelectTournament(tournament) },
          onJoinClick = { onSelectTournament(tournament) }
        )
      }
    }
  }
}

@Composable
fun BannerCarousel(
  banners: List<PromotionalBanner>,
  onBannerClick: (PromotionalBanner) -> Unit
) {
  val pagerState = rememberPagerState(pageCount = { banners.size })
  val coroutineScope = rememberCoroutineScope()
  val context = LocalContext.current

  // Auto-play timer
  LaunchedEffect(pagerState) {
    while (true) {
      delay(4000)
      if (banners.size > 1) {
        val nextPage = (pagerState.currentPage + 1) % banners.size
        pagerState.animateScrollToPage(nextPage)
      }
    }
  }

  Column(modifier = Modifier.padding(top = 10.dp)) {
    HorizontalPager(
      state = pagerState,
      modifier = Modifier
        .fillMaxWidth()
        .height(180.dp),
      contentPadding = PaddingValues(horizontal = 16.dp),
      pageSpacing = 12.dp
    ) { page ->
      val banner = banners[page]
      Card(
        colors = CardDefaults.cardColors(containerColor = CarbonCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, EmeraldDark))),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
          .fillMaxSize()
          .clickable { onBannerClick(banner) }
          .testTag("banner_item_$page")
      ) {
        Box(modifier = Modifier.fillMaxSize()) {
          // If banner has drawable resource name
          val imageModel: Any = if (banner.customImageUri.isNotBlank()) {
            banner.customImageUri
          } else {
            val resId = context.resources.getIdentifier(banner.imageResName, "drawable", context.packageName)
            if (resId != 0) resId else banner.imageResName
          }

          AsyncImage(
            model = imageModel,
            contentDescription = banner.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
          )

          // Gradient Overlay to ensure crisp readability
          Box(
            modifier = Modifier
              .fillMaxSize()
              .background(
                Brush.verticalGradient(
                  colors = listOf(Color.Transparent, Color(0xDD08090E)),
                  startY = 60f
                )
              )
          )

          // Banner text details
          Column(
            modifier = Modifier
              .align(Alignment.BottomStart)
              .padding(14.dp)
          ) {
            Text(
              text = banner.title,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Black,
              color = EmeraldNeon,
              letterSpacing = 0.5.sp
            )
            Text(
              text = banner.subtitle,
              style = MaterialTheme.typography.bodySmall,
              color = TextPrimary,
              maxLines = 1
            )
          }
        }
      }
    }

    // Pager indicator dots
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(top = 8.dp),
      horizontalArrangement = Arrangement.Center
    ) {
      repeat(banners.size) { iteration ->
        val color = if (pagerState.currentPage == iteration) EmeraldNeon else CarbonBorder
        Box(
          modifier = Modifier
            .padding(2.dp)
            .clip(CircleShape)
            .background(color)
            .size(if (pagerState.currentPage == iteration) 18.dp else 6.dp, 6.dp)
        )
      }
    }
  }
}

@Composable
fun QuickStatsCard(
  walletBalance: Double,
  onDepositClick: () -> Unit
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = CarbonCard),
    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, CarbonBorder))),
    shape = RoundedCornerShape(16.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .padding(16.dp)
        .fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(text = "TOTAL WALLET BALANCE", style = MaterialTheme.typography.labelSmall, color = TextMuted)
        Spacer(modifier = Modifier.height(2.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "₹${"%.2f".format(walletBalance)}",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 24.sp,
            color = TextPrimary
          )
          Spacer(modifier = Modifier.width(6.dp))
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(EmeraldDark.copy(alpha = 0.3f))
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(text = "ACTIVE", style = MaterialTheme.typography.labelSmall, color = EmeraldNeon, fontSize = 9.sp)
          }
        }
      }

      Button(
        onClick = onDepositClick,
        colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground),
        shape = RoundedCornerShape(10.dp),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
        modifier = Modifier.testTag("btn_quick_add_money")
      ) {
        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = "ADD MONEY", fontWeight = FontWeight.Black, fontSize = 12.sp)
      }
    }
  }
}

/**
 * CLEAN MATCH CARD WITHOUT THUMBNAIL/BANNER IMAGES
 * Per explicit specification: "Clean match cards WITHOUT thumbnail/banner images (Text, badges, format tags, prize pool, and time only as requested)."
 */
@Composable
fun MatchCardItem(
  tournament: Tournament,
  onCardClick: () -> Unit,
  onJoinClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    onClick = onCardClick,
    colors = CardDefaults.cardColors(containerColor = CarbonCard),
    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, CarbonBorder))),
    shape = RoundedCornerShape(14.dp),
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 6.dp)
      .testTag("match_card_${tournament.id}")
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      // Header: Badges and Status
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          FormatBadge(format = tournament.format)
          MapBadge(mapName = tournament.mapName)
        }
        StatusBadge(status = tournament.status)
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Match Title
      Text(
        text = tournament.title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = TextPrimary
      )

      // Time & Date info
      Text(
        text = "${tournament.matchDate} • Start: ${tournament.startTime}",
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary,
        fontSize = 12.sp
      )

      Spacer(modifier = Modifier.height(12.dp))

      // Numerical Prize & Entry Grid
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(8.dp))
          .background(CarbonCardElevated)
          .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text(text = "PRIZE POOL", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
          Text(
            text = "₹${tournament.totalPrizePool.toInt()}",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = AmberGold
          )
        }
        Column {
          Text(text = "1ST PRIZE", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
          Text(
            text = "₹${tournament.firstPrize.toInt()}",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = EmeraldNeon
          )
        }
        Column {
          Text(text = "PER KILL", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
          Text(
            text = "₹${tournament.perKillBonus.toInt()}",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = NeonCyan
          )
        }
        Column {
          Text(text = "ENTRY FEE", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
          Text(
            text = "₹${tournament.entryFee.toInt()}",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = TextPrimary
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Slots Progress Bar
      val progress = if (tournament.totalSlots > 0) tournament.filledSlots.toFloat() / tournament.totalSlots else 0f
      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "Spots: ${tournament.filledSlots}/${tournament.totalSlots} filled",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            fontSize = 11.sp
          )
          Text(
            text = "${(tournament.totalSlots - tournament.filledSlots).coerceAtLeast(0)} left",
            style = MaterialTheme.typography.labelSmall,
            color = if (tournament.filledSlots >= tournament.totalSlots) CrimsonAlert else EmeraldNeon,
            fontSize = 11.sp
          )
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
          progress = { progress },
          modifier = Modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp)),
          color = if (progress >= 1f) CrimsonAlert else EmeraldNeon,
          trackColor = CarbonBorder,
        )

        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.End,
          verticalAlignment = Alignment.CenterVertically
        ) {
          val actionLabel = when {
            tournament.status == MatchStatus.CANCELLED -> "Match Cancelled"
            tournament.status == MatchStatus.LIVE -> "Match Live • In Progress"
            tournament.status == MatchStatus.COMPLETED -> "Match Completed"
            tournament.filledSlots >= tournament.totalSlots -> "Slots Full"
            else -> "Tap to View Details & Join →"
          }
          val actionColor = when {
            tournament.status == MatchStatus.CANCELLED -> CrimsonAlert
            tournament.status == MatchStatus.LIVE -> AmberGold
            tournament.status == MatchStatus.COMPLETED -> TextMuted
            tournament.filledSlots >= tournament.totalSlots -> AmberGold
            else -> NeonCyan
          }
          Text(
            text = actionLabel,
            color = actionColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}
