package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TransactionType
import com.example.data.model.User
import com.example.ui.components.CopyableCodeBox
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CarbonBackground
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonCard
import com.example.ui.theme.CarbonCardElevated
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.TodamentViewModel

@Composable
fun ReferScreen(
  viewModel: TodamentViewModel
) {
  val context = LocalContext.current
  val currentUser by viewModel.currentUser.collectAsState()
  val userTransactions by viewModel.userTransactions.collectAsState()
  val allUsers by viewModel.allUsers.collectAsState()
  val appSettings by viewModel.appSettings.collectAsState()

  val myReferralCode = currentUser?.referralCode ?: "TODA-1001"
  val shareableLink = "https://todament.esports/join?ref=$myReferralCode"
  val shareText = "🎮 Join me on TODAMENT — India's premier Free Fire esports cash scrim app! Register for tournaments, win instant cash, and withdraw to UPI. Use my referral code: $myReferralCode to join now: $shareableLink"

  // Calculate Referral stats
  val invitedFriends = remember(allUsers, myReferralCode) {
    allUsers.filter { it.referredByCode.equals(myReferralCode, ignoreCase = true) }
  }

  val activeWinners = remember(invitedFriends) {
    invitedFriends.filter { it.totalWinnings > 0 }
  }

  val totalReferralEarned = remember(userTransactions) {
    userTransactions.filter { it.type == TransactionType.REFERRAL_BONUS }.sumOf { it.amount }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CarbonBackground)
  ) {
    // Header
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .background(CarbonSurface)
        .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
      Text(
        text = "REFER & EARN REWARDS",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Black,
        color = TextPrimary,
        letterSpacing = 1.sp
      )
      Text(
        text = "Invite squadmates and earn passive commission on every match victory",
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary
      )
    }

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 90.dp)
    ) {
      // 1. REWARD HERO CARD
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = CarbonCard),
          border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, EmeraldDark))),
          shape = RoundedCornerShape(18.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(20.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(text = "TOTAL COMMISSIONS EARNED", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                Text(
                  text = "₹${"%.2f".format(totalReferralEarned)}",
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Black,
                  fontSize = 32.sp,
                  color = AmberGold
                )
              }
              Box(
                modifier = Modifier
                  .size(48.dp)
                  .clip(RoundedCornerShape(12.dp))
                  .background(EmeraldDark.copy(alpha = 0.25f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.CardGiftcard, contentDescription = null, tint = EmeraldNeon, modifier = Modifier.size(28.dp))
              }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Multi-Tier Rules Info Box
            Card(
              colors = CardDefaults.cardColors(containerColor = CarbonCardElevated),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text(text = "MULTI-TIER REWARDS STRUCTURE", style = MaterialTheme.typography.labelSmall, color = NeonCyan, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(text = "• Tier 1:", fontWeight = FontWeight.Bold, color = EmeraldNeon, fontSize = 12.sp)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(text = "${appSettings.referralFirstWinPercent.toInt()}% bonus on your invited friend's FIRST tournament win", style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontSize = 11.sp)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(text = "• Tier 2:", fontWeight = FontWeight.Bold, color = AmberGold, fontSize = 12.sp)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(text = "${appSettings.referralSubsequentWinPercent.toInt()}% bonus on ALL subsequent tournament wins by that friend", style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontSize = 11.sp)
                }
              }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Copyable Referral Code Box
            CopyableCodeBox(
              label = "YOUR UNIQUE REFERRAL CODE",
              value = myReferralCode,
              testTag = "box_my_referral_code"
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 1-Tap Social Share Buttons (WhatsApp & Telegram)
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Button(
                onClick = {
                  try {
                    val waIntent = Intent(Intent.ACTION_VIEW).apply {
                      data = Uri.parse("https://api.whatsapp.com/send?text=${Uri.encode(shareText)}")
                    }
                    context.startActivity(waIntent)
                  } catch (e: Exception) {
                    val share = Intent(Intent.ACTION_SEND).apply {
                      type = "text/plain"
                      putExtra(Intent.EXTRA_TEXT, shareText)
                    }
                    context.startActivity(Intent.createChooser(share, "Share via"))
                  }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366), contentColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                  .weight(1f)
                  .testTag("btn_share_whatsapp")
              ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "WhatsApp", fontWeight = FontWeight.Bold)
              }

              Button(
                onClick = {
                  try {
                    val tgIntent = Intent(Intent.ACTION_VIEW).apply {
                      data = Uri.parse("https://t.me/share/url?url=${Uri.encode(shareableLink)}&text=${Uri.encode(shareText)}")
                    }
                    context.startActivity(tgIntent)
                  } catch (e: Exception) {
                    val share = Intent(Intent.ACTION_SEND).apply {
                      type = "text/plain"
                      putExtra(Intent.EXTRA_TEXT, shareText)
                    }
                    context.startActivity(Intent.createChooser(share, "Share via"))
                  }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF229ED9), contentColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                  .weight(1f)
                  .testTag("btn_share_telegram")
              ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "Telegram", fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }

      // 2. LIVE LEDGER STATS
      item {
        Spacer(modifier = Modifier.height(20.dp))
        Text(
          text = "REFERRAL NETWORK STATS",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Card(
            colors = CardDefaults.cardColors(containerColor = CarbonCard),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.weight(1f)
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Text(text = "Invited Friends", style = MaterialTheme.typography.labelSmall, color = TextMuted)
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "${invitedFriends.size}",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 24.sp,
                color = EmeraldNeon
              )
            }
          }

          Card(
            colors = CardDefaults.cardColors(containerColor = CarbonCard),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.weight(1f)
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Text(text = "Active Winners", style = MaterialTheme.typography.labelSmall, color = TextMuted)
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "${activeWinners.size}",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 24.sp,
                color = NeonCyan
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(18.dp))
        Text(
          text = "INVITED FRIENDS LIST",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )
        Spacer(modifier = Modifier.height(8.dp))
      }

      // Invited Friends List
      if (invitedFriends.isEmpty()) {
        item {
          Card(
            colors = CardDefaults.cardColors(containerColor = CarbonCard),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text(
                text = "No friends invited yet",
                style = MaterialTheme.typography.titleSmall,
                color = TextSecondary
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Share your code on WhatsApp & Discord to start earning daily match commissions!",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
              )
            }
          }
        }
      } else {
        items(invitedFriends) { friend ->
          Card(
            colors = CardDefaults.cardColors(containerColor = CarbonCard),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(CarbonCardElevated),
                  contentAlignment = Alignment.Center
                ) {
                  Text(
                    text = friend.freeFireIgn.take(2).uppercase(),
                    color = EmeraldNeon,
                    fontWeight = FontWeight.Bold
                  )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                  Text(text = friend.freeFireIgn, style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                  Text(text = "UID: ${friend.freeFireUid}", style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 11.sp)
                }
              }

              Column(horizontalAlignment = Alignment.End) {
                Text(
                  text = if (friend.totalWinnings > 0) "Won ₹${friend.totalWinnings.toInt()}" else "Joined",
                  style = MaterialTheme.typography.labelSmall,
                  color = if (friend.totalWinnings > 0) AmberGold else TextSecondary,
                  fontWeight = FontWeight.Bold
                )
                Text(text = "Active Player", style = MaterialTheme.typography.bodySmall, color = EmeraldNeon, fontSize = 10.sp)
              }
            }
          }
        }
      }
    }
  }
}
