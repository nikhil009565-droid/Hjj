package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.model.RequestStatus
import com.example.data.model.TransactionType
import com.example.data.model.WalletTransaction
import com.example.ui.components.CopyableCodeBox
import com.example.ui.components.ZoomableImageDialog
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CarbonBackground
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonCard
import com.example.ui.theme.CarbonCardElevated
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.TodamentViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun WalletScreen(
  viewModel: TodamentViewModel
) {
  val currentUser by viewModel.currentUser.collectAsState()
  val filteredTransactions by viewModel.filteredTransactions.collectAsState()
  val selectedFilter by viewModel.transactionFilter.collectAsState()
  val appSettings by viewModel.appSettings.collectAsState()
  val userDeposits by viewModel.userDeposits.collectAsState()
  val userWithdrawals by viewModel.userWithdrawals.collectAsState()

  var showDepositModal by remember { mutableStateOf(false) }
  var showWithdrawalModal by remember { mutableStateOf(false) }
  var previewScreenshotUrl by remember { mutableStateOf<String?>(null) }

  val filterOptions = listOf("All", "Deposits", "Winnings", "Entry Fees", "Refunds", "Referrals")

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CarbonBackground)
  ) {
    // Header
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .background(CarbonSurface)
        .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
      Text(
        text = "ESPORTS WALLET",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Black,
        color = TextPrimary,
        letterSpacing = 1.sp
      )
      Text(
        text = "Instant UPI deposits, fast withdrawals, and transaction records",
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary
      )
    }

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 90.dp)
    ) {
      // 1. WALLET BALANCES MASTER CARD
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = CarbonCard),
          border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, EmeraldDark))),
          shape = RoundedCornerShape(18.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(20.dp)) {
            Text(text = "CURRENT AVAILABLE BALANCE", style = MaterialTheme.typography.labelSmall, color = TextMuted)
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.Bottom) {
              Text(
                text = "₹${"%.2f".format(currentUser?.walletBalance ?: 0.0)}",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 32.sp,
                color = EmeraldNeon
              )
              if ((currentUser?.reservedForWithdrawal ?: 0.0) > 0.0) {
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                  text = "(₹${"%.0f".format(currentUser?.reservedForWithdrawal)} reserved)",
                  style = MaterialTheme.typography.bodySmall,
                  color = AmberGold,
                  modifier = Modifier.padding(bottom = 6.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Sub-metrics 3-column row
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(CarbonCardElevated)
                .padding(12.dp),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Text(text = "Deposited", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 10.sp)
                Text(
                  text = "₹${"%.0f".format(currentUser?.totalDeposited ?: 0.0)}",
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary
                )
              }
              Column {
                Text(text = "Winnings", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 10.sp)
                Text(
                  text = "₹${"%.0f".format(currentUser?.totalWinnings ?: 0.0)}",
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  color = AmberGold
                )
              }
              Column {
                Text(text = "Withdrawn", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 10.sp)
                Text(
                  text = "₹${"%.0f".format(currentUser?.totalWithdrawn ?: 0.0)}",
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  color = NeonCyan
                )
              }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Action Buttons: Deposit & Withdraw
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              Button(
                onClick = { showDepositModal = true },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                  .weight(1f)
                  .height(48.dp)
                  .testTag("btn_wallet_deposit")
              ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "DEPOSIT UPI", fontWeight = FontWeight.Black)
              }

              Button(
                onClick = { showWithdrawalModal = true },
                colors = ButtonDefaults.buttonColors(containerColor = CarbonCardElevated, contentColor = TextPrimary),
                border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, CarbonBorder))),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                  .weight(1f)
                  .height(48.dp)
                  .testTag("btn_wallet_withdraw")
              ) {
                Icon(Icons.Default.Payments, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "WITHDRAW", fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }

      // PENDING REQUESTS ALERTS (If any)
      val pendingDeposits = userDeposits.filter { it.status == RequestStatus.PENDING }
      val pendingWithdrawals = userWithdrawals.filter { it.status == RequestStatus.PENDING }

      if (pendingDeposits.isNotEmpty() || pendingWithdrawals.isNotEmpty()) {
        item {
          Spacer(modifier = Modifier.height(14.dp))
          Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2614)),
            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(AmberGold.copy(alpha = 0.5f), AmberGold.copy(alpha = 0.5f)))),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.HourglassEmpty, contentDescription = null, tint = AmberGold, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "PENDING REVIEWS IN PROGRESS",
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = AmberGold
                )
              }
              Spacer(modifier = Modifier.height(4.dp))
              if (pendingDeposits.isNotEmpty()) {
                Text(
                  text = "• ${pendingDeposits.size} UPI deposit(s) awaiting admin UTR verification.",
                  style = MaterialTheme.typography.bodySmall,
                  color = TextSecondary
                )
              }
              if (pendingWithdrawals.isNotEmpty()) {
                Text(
                  text = "• ${pendingWithdrawals.size} withdrawal request(s) queued for bank transfer.",
                  style = MaterialTheme.typography.bodySmall,
                  color = TextSecondary
                )
              }
            }
          }
        }
      }

      // 2. TRANSACTION HISTORY & FILTER TABS
      item {
        Spacer(modifier = Modifier.height(20.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "TRANSACTION LEDGER",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          contentPadding = PaddingValues(vertical = 4.dp)
        ) {
          items(filterOptions) { filter ->
            val isSelected = selectedFilter == filter
            Surface(
              onClick = { viewModel.selectTransactionFilter(filter) },
              shape = RoundedCornerShape(16.dp),
              color = if (isSelected) NeonCyan else CarbonCard,
              border = if (!isSelected) CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, CarbonBorder))) else null,
              modifier = Modifier.testTag("tx_filter_$filter")
            ) {
              Text(
                text = filter,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) CarbonBackground else TextSecondary,
                fontSize = 11.sp
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))
      }

      // Transactions List
      if (filteredTransactions.isEmpty()) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "No transactions found in this category.",
              style = MaterialTheme.typography.bodyMedium,
              color = TextMuted
            )
          }
        }
      } else {
        items(filteredTransactions) { tx ->
          TransactionItemCard(tx = tx)
        }
      }
    }
  }

  // --- NATIVE 1-TAP UPI DEPOSIT MODAL ---
  if (showDepositModal) {
    UpiDepositDialog(
      adminUpiId = appSettings.adminUpiId,
      adminPayeeName = appSettings.adminPayeeName,
      qrCodeImageUri = appSettings.qrCodeImageUri,
      minDeposit = appSettings.minDepositAmount,
      onDismiss = { showDepositModal = false },
      onSubmit = { amount, utr, screenshotUri ->
        viewModel.submitDeposit(
          amount = amount,
          utr = utr,
          screenshotUri = screenshotUri,
          onSuccess = { showDepositModal = false }
        )
      }
    )
  }

  // --- INSTANT WITHDRAWAL MODAL ---
  if (showWithdrawalModal) {
    UpiWithdrawalDialog(
      availableBalance = currentUser?.walletBalance ?: 0.0,
      minWithdrawal = appSettings.minWithdrawalAmount,
      onDismiss = { showWithdrawalModal = false },
      onSubmit = { amount, upiId, accountName ->
        viewModel.submitWithdrawal(
          amount = amount,
          upiId = upiId,
          accountHolderName = accountName,
          onSuccess = { showWithdrawalModal = false }
        )
      }
    )
  }

  // Screenshot Zoom Preview Modal
  previewScreenshotUrl?.let { url ->
    ZoomableImageDialog(
      imageUrl = url,
      onDismiss = { previewScreenshotUrl = null }
    )
  }
}

@Composable
fun TransactionItemCard(tx: WalletTransaction) {
  val isCredit = tx.type.isCredit
  val amountColor = if (isCredit) EmeraldNeon else CrimsonAlert
  val iconVector = when (tx.type) {
    TransactionType.DEPOSIT -> Icons.Default.ArrowDownward
    TransactionType.WINNING -> Icons.Default.Payments
    TransactionType.ENTRY_FEE -> Icons.Default.ArrowUpward
    TransactionType.REFUND -> Icons.Default.CheckCircle
    TransactionType.REFERRAL_BONUS -> Icons.Default.Payments
    TransactionType.WITHDRAWAL -> Icons.Default.ArrowUpward
  }

  val dateStr = remember(tx.timestamp) {
    val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
    sdf.format(Date(tx.timestamp))
  }

  Card(
    colors = CardDefaults.cardColors(containerColor = CarbonCard),
    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, CarbonBorder))),
    shape = RoundedCornerShape(12.dp),
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (isCredit) EmeraldDark.copy(alpha = 0.2f) else CarbonBorder),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = iconVector,
            contentDescription = null,
            tint = if (isCredit) EmeraldNeon else TextSecondary,
            modifier = Modifier.size(18.dp)
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = tx.title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
          if (tx.description.isNotBlank()) {
            Text(
              text = tx.description,
              style = MaterialTheme.typography.bodySmall,
              color = TextSecondary,
              fontSize = 11.sp
            )
          }
          Text(
            text = dateStr,
            style = MaterialTheme.typography.bodySmall,
            color = TextMuted,
            fontSize = 10.sp
          )
        }
      }

      Text(
        text = "${if (isCredit) "+" else "-"}₹${"%.0f".format(tx.amount)}",
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 15.sp,
        color = amountColor
      )
    }
  }
}

/**
 * NATIVE 1-TAP UPI DEPOSIT DIALOG
 * Direct Native Android Intent launcher using:
 * upi://pay?pa={ADMIN_UPI}&pn={ADMIN_NAME}&am={AMOUNT}&cu=INR
 * Opens Android native App Chooser showing ONLY UPI apps installed on user's phone.
 * Supports Gallery screenshot picking and 12-digit UTR validation.
 */
@Composable
fun UpiDepositDialog(
  adminUpiId: String,
  adminPayeeName: String,
  qrCodeImageUri: String = "",
  minDeposit: Double,
  onDismiss: () -> Unit,
  onSubmit: (Double, String, String) -> Unit
) {
  val context = LocalContext.current
  var selectedAmount by remember { mutableDoubleStateOf(100.0) }
  var customAmountStr by remember { mutableStateOf("100") }
  var utrNumber by remember { mutableStateOf("") }
  var screenshotUri by remember { mutableStateOf("") }
  var showQrPreview by remember { mutableStateOf(false) }

  val presetAmounts = listOf(50.0, 100.0, 200.0, 500.0)

  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia(),
    onResult = { uri ->
      if (uri != null) {
        screenshotUri = uri.toString()
        Toast.makeText(context, "Screenshot selected!", Toast.LENGTH_SHORT).show()
      }
    }
  )

  val scrollState = rememberScrollState()

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = CarbonCardElevated,
      border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, EmeraldDark))),
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 14.dp)
    ) {
      Column(
        modifier = Modifier
          .padding(20.dp)
          .verticalScroll(scrollState)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Payments, contentDescription = null, tint = EmeraldNeon, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = "ADD MONEY VIA UPI", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = TextPrimary)
          }
          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Preset Chips
        Text(text = "SELECT AMOUNT", style = MaterialTheme.typography.labelSmall, color = TextMuted)
        Spacer(modifier = Modifier.height(6.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          presetAmounts.forEach { amt ->
            val isSelected = selectedAmount == amt
            Surface(
              onClick = {
                selectedAmount = amt
                customAmountStr = amt.toInt().toString()
              },
              shape = RoundedCornerShape(8.dp),
              color = if (isSelected) EmeraldNeon else CarbonCard,
              border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, CarbonBorder))),
              modifier = Modifier
                .weight(1f)
                .testTag("preset_amt_${amt.toInt()}")
            ) {
              Text(
                text = "₹${amt.toInt()}",
                modifier = Modifier.padding(vertical = 10.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) CarbonBackground else TextPrimary,
                fontSize = 13.sp
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = customAmountStr,
          onValueChange = {
            customAmountStr = it
            selectedAmount = it.toDoubleOrNull() ?: 0.0
          },
          label = { Text("Or Enter Custom Amount (Min ₹${minDeposit.toInt()})") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = EmeraldNeon,
            unfocusedBorderColor = CarbonBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          ),
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_deposit_amount")
        )

        Spacer(modifier = Modifier.height(14.dp))

        // 1-TAP NATIVE UPI INTENT LAUNCHER BUTTON
        Button(
          onClick = {
            val amountVal = customAmountStr.toDoubleOrNull() ?: selectedAmount
            if (amountVal < minDeposit) {
              Toast.makeText(context, "Minimum deposit is ₹${minDeposit.toInt()}", Toast.LENGTH_SHORT).show()
              return@Button
            }
            // Construct UPI URI
            val upiUri = Uri.parse("upi://pay?pa=$adminUpiId&pn=${Uri.encode(adminPayeeName)}&am=$amountVal&cu=INR&tn=${Uri.encode("Todament Topup")}")
            val intent = Intent(Intent.ACTION_VIEW, upiUri)
            val chooser = Intent.createChooser(intent, "Pay via Installed UPI App")
            try {
              context.startActivity(chooser)
            } catch (e: Exception) {
              Toast.makeText(context, "No UPI app detected. Please copy the UPI ID below to pay.", Toast.LENGTH_LONG).show()
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("btn_launch_native_upi")
        ) {
          Icon(Icons.Default.Payments, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "PAY NOW VIA INSTALLED UPI APPS", fontWeight = FontWeight.Black, fontSize = 13.sp)
        }

        val amountVal = customAmountStr.toDoubleOrNull() ?: selectedAmount
        val activeQrUrl = if (qrCodeImageUri.isNotBlank()) {
          qrCodeImageUri
        } else {
          "https://api.qrserver.com/v1/create-qr-code/?size=450x450&margin=8&data=" + Uri.encode(
            "upi://pay?pa=$adminUpiId&pn=${Uri.encode(adminPayeeName)}&am=$amountVal&cu=INR&tn=${Uri.encode("Todament Topup")}"
          )
        }

        // --- OFFICIAL UPI QR CODE CARD (DIRECTLY ABOVE UPI ID) ---
        Card(
          colors = CardDefaults.cardColors(containerColor = CarbonCard),
          border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, EmeraldDark))),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("card_deposit_upi_qr")
        ) {
          Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.Center,
              modifier = Modifier.fillMaxWidth()
            ) {
              Icon(Icons.Default.QrCode2, contentDescription = null, tint = EmeraldNeon, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "SCAN & PAY UPI QR CODE",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Black,
                color = EmeraldNeon,
                letterSpacing = 0.5.sp
              )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = "PhonePe • Google Pay • Paytm • BHIM UPI",
              style = MaterialTheme.typography.bodySmall,
              color = TextSecondary,
              fontSize = 10.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            // High-contrast QR Container
            Box(
              modifier = Modifier
                .size(160.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.White)
                .clickable { showQrPreview = true }
                .padding(8.dp),
              contentAlignment = Alignment.Center
            ) {
              AsyncImage(
                model = activeQrUrl,
                contentDescription = "UPI Payment QR Code",
                modifier = Modifier.fillMaxSize()
              )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.Center,
              modifier = Modifier.clickable { showQrPreview = true }
            ) {
              Icon(Icons.Default.ZoomIn, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "Tap to enlarge QR Code",
                style = MaterialTheme.typography.bodySmall,
                color = NeonCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Official UPI ID Copy Box
        CopyableCodeBox(
          label = "OFFICIAL ADMIN UPI ID",
          value = adminUpiId,
          testTag = "box_admin_upi_id"
        )

        Spacer(modifier = Modifier.height(16.dp))

        // UTR & Screenshot Verification Form
        Text(text = "STEP 2: SUBMIT PAYMENT PROOF", style = MaterialTheme.typography.labelSmall, color = AmberGold, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))

        OutlinedTextField(
          value = utrNumber,
          onValueChange = { if (it.length <= 12 && it.all { ch -> ch.isDigit() }) utrNumber = it },
          label = { Text("12-Digit UTR / UPI Ref No.") },
          placeholder = { Text("e.g. 428910294819") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = EmeraldNeon,
            unfocusedBorderColor = CarbonBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          ),
          singleLine = true,
          supportingText = { Text("${utrNumber.length}/12 digits", color = if (utrNumber.length == 12) EmeraldNeon else TextMuted) },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_deposit_utr")
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Screenshot Picker Button
        OutlinedButton(
          onClick = {
            photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
          },
          colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
          border = ButtonDefaults.outlinedButtonBorder.copy(
            brush = Brush.horizontalGradient(if (screenshotUri.isNotBlank()) listOf(EmeraldDark, EmeraldNeon) else listOf(CarbonBorder, CarbonBorder))
          ),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("btn_pick_screenshot")
        ) {
          Icon(Icons.Default.Image, contentDescription = null, tint = if (screenshotUri.isNotBlank()) EmeraldNeon else NeonCyan)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (screenshotUri.isNotBlank()) "Screenshot Selected ✓ (Tap to change)" else "Upload Payment Screenshot",
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp
          )
        }

        Spacer(modifier = Modifier.height(18.dp))

        Button(
          onClick = {
            val amountVal = customAmountStr.toDoubleOrNull() ?: selectedAmount
            if (amountVal < minDeposit) {
              Toast.makeText(context, "Minimum deposit is ₹${minDeposit.toInt()}", Toast.LENGTH_SHORT).show()
              return@Button
            }
            if (utrNumber.length != 12) {
              Toast.makeText(context, "Please enter a valid 12-digit numeric UTR number", Toast.LENGTH_SHORT).show()
              return@Button
            }
            onSubmit(amountVal, utrNumber, screenshotUri)
          },
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark, contentColor = TextPrimary),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag("btn_submit_deposit_review")
        ) {
          Text(text = "SUBMIT FOR VERIFICATION", fontWeight = FontWeight.Bold)
        }
      }
    }
  }

  if (showQrPreview) {
    val amountVal = customAmountStr.toDoubleOrNull() ?: selectedAmount
    val previewQrUrl = if (qrCodeImageUri.isNotBlank()) {
      qrCodeImageUri
    } else {
      "https://api.qrserver.com/v1/create-qr-code/?size=600x600&margin=10&data=" + Uri.encode(
        "upi://pay?pa=$adminUpiId&pn=${Uri.encode(adminPayeeName)}&am=$amountVal&cu=INR&tn=${Uri.encode("Todament Topup")}"
      )
    }
    ZoomableImageDialog(imageUrl = previewQrUrl, onDismiss = { showQrPreview = false })
  }
}

/**
 * INSTANT UPI WITHDRAWAL MODAL
 * Deducts into "Reserved" immediately to prevent double spending.
 */
@Composable
fun UpiWithdrawalDialog(
  availableBalance: Double,
  minWithdrawal: Double,
  onDismiss: () -> Unit,
  onSubmit: (Double, String, String) -> Unit
) {
  val context = LocalContext.current
  var amountStr by remember { mutableStateOf("100") }
  var upiId by remember { mutableStateOf("") }
  var accountHolderName by remember { mutableStateOf("") }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = CarbonCardElevated,
    title = {
      Column {
        Text(text = "Instant UPI Withdrawal", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = TextPrimary)
        Text(text = "Available to withdraw: ₹${"%.2f".format(availableBalance)}", style = MaterialTheme.typography.bodySmall, color = EmeraldNeon)
      }
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text(
          text = "Min withdrawal limit: ₹${minWithdrawal.toInt()}. Funds are locked into reserved immediately to prevent double spend.",
          style = MaterialTheme.typography.bodySmall,
          color = TextSecondary,
          fontSize = 11.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = amountStr,
          onValueChange = { amountStr = it },
          label = { Text("Withdrawal Amount (₹)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = EmeraldNeon,
            unfocusedBorderColor = CarbonBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          ),
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_withdraw_amount")
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = upiId,
          onValueChange = { upiId = it },
          label = { Text("Recipient UPI ID") },
          placeholder = { Text("e.g. gamer@oksbi") },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = EmeraldNeon,
            unfocusedBorderColor = CarbonBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          ),
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_withdraw_upi")
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = accountHolderName,
          onValueChange = { accountHolderName = it },
          label = { Text("Account Holder Full Name") },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = EmeraldNeon,
            unfocusedBorderColor = CarbonBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          ),
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_withdraw_name")
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val amt = amountStr.toDoubleOrNull() ?: 0.0
          if (amt < minWithdrawal) {
            Toast.makeText(context, "Minimum withdrawal is ₹${minWithdrawal.toInt()}", Toast.LENGTH_SHORT).show()
            return@Button
          }
          if (amt > availableBalance) {
            Toast.makeText(context, "Insufficient balance!", Toast.LENGTH_SHORT).show()
            return@Button
          }
          if (!upiId.contains("@") || accountHolderName.isBlank()) {
            Toast.makeText(context, "Please enter a valid UPI ID and Name", Toast.LENGTH_SHORT).show()
            return@Button
          }
          onSubmit(amt, upiId, accountHolderName)
        },
        colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground),
        modifier = Modifier.testTag("btn_confirm_withdrawal")
      ) {
        Text("CONFIRM WITHDRAWAL", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("CANCEL", color = TextSecondary)
      }
    }
  )
}
