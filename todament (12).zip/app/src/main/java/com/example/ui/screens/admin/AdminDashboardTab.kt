package com.example.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RequestStatus
import com.example.data.model.TransactionType
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CarbonBackground
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonCard
import com.example.ui.theme.CarbonCardElevated
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.TodamentViewModel

@Composable
fun AdminDashboardTab(viewModel: TodamentViewModel) {
  val allUsers by viewModel.allUsers.collectAsState()
  val tournaments by viewModel.tournaments.collectAsState()
  val allTransactions by viewModel.allTransactions.collectAsState()
  val allDeposits by viewModel.allDepositRequests.collectAsState()
  val allWithdrawals by viewModel.allWithdrawalRequests.collectAsState()

  val totalDeposits = remember(allTransactions) {
    allTransactions.filter { it.type == TransactionType.DEPOSIT }.sumOf { it.amount }
  }
  val totalPrizePayouts = remember(allTransactions) {
    allTransactions.filter { it.type == TransactionType.WINNING }.sumOf { it.amount }
  }
  val totalEntryFees = remember(allTransactions) {
    allTransactions.filter { it.type == TransactionType.ENTRY_FEE }.sumOf { it.amount }
  }
  val platformRevenue = (totalEntryFees - totalPrizePayouts).coerceAtLeast(0.0)

  val pendingDepositsCount = remember(allDeposits) {
    allDeposits.count { it.status == RequestStatus.PENDING }
  }
  val pendingWithdrawalsCount = remember(allWithdrawals) {
    allWithdrawals.count { it.status == RequestStatus.PENDING }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(CarbonBackground),
    contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 90.dp)
  ) {
    // Platform Revenue & Metrics
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = CarbonCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, EmeraldDark))),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(20.dp)) {
          Text(text = "ESTIMATED PLATFORM NET REVENUE", style = MaterialTheme.typography.labelSmall, color = TextMuted)
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "₹${"%.2f".format(platformRevenue)}",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 32.sp,
            color = EmeraldNeon
          )

          Spacer(modifier = Modifier.height(16.dp))

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .background(CarbonCardElevated)
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text(text = "Total Deposits", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 10.sp)
              Text(text = "₹${"%.0f".format(totalDeposits)}", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = TextPrimary)
            }
            Column {
              Text(text = "Entry Collected", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 10.sp)
              Text(text = "₹${"%.0f".format(totalEntryFees)}", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = NeonCyan)
            }
            Column {
              Text(text = "Prizes Paid", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 10.sp)
              Text(text = "₹${"%.0f".format(totalPrizePayouts)}", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AmberGold)
            }
          }
        }
      }
    }

    // Pending Approvals Action Cards
    item {
      Spacer(modifier = Modifier.height(16.dp))
      Text(text = "PENDING ACTION QUEUE", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontWeight = FontWeight.Bold)
      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Card(
          colors = CardDefaults.cardColors(containerColor = if (pendingDepositsCount > 0) Color(0xFF262010) else CarbonCard),
          border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(if (pendingDepositsCount > 0) listOf(AmberGold, AmberGold) else listOf(CarbonBorder, CarbonBorder))
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.weight(1f)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Text(text = "Pending Deposits", style = MaterialTheme.typography.labelSmall, color = TextMuted)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "$pendingDepositsCount",
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Black,
              fontSize = 24.sp,
              color = if (pendingDepositsCount > 0) AmberGold else EmeraldNeon
            )
            Text(text = if (pendingDepositsCount > 0) "Needs UTR verification" else "Queue is clear", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
          }
        }

        Card(
          colors = CardDefaults.cardColors(containerColor = if (pendingWithdrawalsCount > 0) Color(0xFF261014) else CarbonCard),
          border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(if (pendingWithdrawalsCount > 0) listOf(CrimsonAlert, CrimsonAlert) else listOf(CarbonBorder, CarbonBorder))
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.weight(1f)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Text(text = "Pending Payouts", style = MaterialTheme.typography.labelSmall, color = TextMuted)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "$pendingWithdrawalsCount",
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Black,
              fontSize = 24.sp,
              color = if (pendingWithdrawalsCount > 0) CrimsonAlert else EmeraldNeon
            )
            Text(text = if (pendingWithdrawalsCount > 0) "Needs bank transfer" else "Queue is clear", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
          }
        }
      }
    }

    // Platform Health
    item {
      Spacer(modifier = Modifier.height(18.dp))
      Text(text = "OPERATIONAL OVERVIEW", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontWeight = FontWeight.Bold)
      Spacer(modifier = Modifier.height(8.dp))

      Card(
        colors = CardDefaults.cardColors(containerColor = CarbonCard),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "Registered Gamers", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
            Text(text = "${allUsers.size}", color = TextPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
          }
          Spacer(modifier = Modifier.height(8.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "Total Matches Created", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
            Text(text = "${tournaments.size}", color = TextPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
          }
          Spacer(modifier = Modifier.height(8.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "Total System Transactions", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
            Text(text = "${allTransactions.size}", color = TextPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
          }
        }
      }
    }
  }
}
