package com.example.ui.screens.admin

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MatchStatus
import com.example.data.model.Registration
import com.example.data.model.Tournament
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CarbonBackground
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonCard
import com.example.ui.theme.CarbonCardElevated
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.TodamentViewModel

@Composable
fun AdminResultsTab(viewModel: TodamentViewModel) {
  val tournaments by viewModel.tournaments.collectAsState()
  var selectedTournament by remember { mutableStateOf<Tournament?>(null) }
  val context = LocalContext.current

  // Filter tournaments that are not cancelled
  val activeTournaments = remember(tournaments) {
    tournaments.filter { it.status != MatchStatus.CANCELLED }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CarbonBackground)
  ) {
    if (selectedTournament == null) {
      // Pick tournament to declare results
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 90.dp)
      ) {
        item {
          Text(
            text = "SELECT MATCH TO DECLARE RESULTS & DISTRIBUTE PRIZES",
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(10.dp))
        }

        if (activeTournaments.isEmpty()) {
          item {
            Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
              Text("No active matches found", color = TextMuted)
            }
          }
        } else {
          items(activeTournaments) { tourn ->
            Card(
              onClick = { selectedTournament = tourn },
              colors = CardDefaults.cardColors(containerColor = CarbonCard),
              border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, CarbonBorder))),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .testTag("result_pick_${tourn.id}")
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(text = tourn.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                  Text(text = "Prize Pool: ₹${tourn.totalPrizePool.toInt()} • Status: ${tourn.status.displayName}", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
                }

                Button(
                  onClick = { selectedTournament = tourn },
                  colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark),
                  shape = RoundedCornerShape(8.dp),
                  contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                  Text("Enter Results", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }
      }
    } else {
      // Results Entry Form for Selected Match
      val tourn = selectedTournament!!
      val registrationsFlow = viewModel.repository.getRegistrationsForTournament(tourn.id)
      val registrations by registrationsFlow.collectAsState(initial = emptyList())

      ResultsEntryView(
        tournament = tourn,
        registrations = registrations,
        viewModel = viewModel,
        onBack = { selectedTournament = null },
        onSubmitPrizes = { updatedList ->
          viewModel.distributePrizes(tourn.id, updatedList) {
            Toast.makeText(context, "Prizes successfully distributed into player wallets!", Toast.LENGTH_LONG).show()
            selectedTournament = null
          }
        }
      )
    }
  }
}

@Composable
fun ResultsEntryView(
  tournament: Tournament,
  registrations: List<Registration>,
  viewModel: TodamentViewModel,
  onBack: () -> Unit,
  onSubmitPrizes: (List<Registration>) -> Unit
) {
  val context = LocalContext.current
  val allUsers by viewModel.allUsers.collectAsState()

  // Local state for placement and kills per registration
  val ranks = remember(registrations) {
    mutableStateListOf<Int>().apply {
      registrations.forEachIndexed { index, reg ->
        add(if (reg.placementRank > 0) reg.placementRank else index + 1)
      }
    }
  }

  val kills = remember(registrations) {
    mutableStateListOf<Int>().apply {
      registrations.forEach { reg ->
        add(reg.kills)
      }
    }
  }

  // Custom Editable Prize Strings per player
  val customPrizes = remember(registrations) {
    mutableStateListOf<String>().apply {
      registrations.forEachIndexed { index, reg ->
        val rank = if (reg.placementRank > 0) reg.placementRank else index + 1
        val placementPrize = when (rank) {
          1 -> tournament.firstPrize
          2 -> tournament.secondPrize
          3 -> tournament.thirdPrize
          else -> 0.0
        }
        val defaultAmt = if (reg.prizeWon > 0.0) reg.prizeWon else (placementPrize + (reg.kills * tournament.perKillBonus))
        add(if (defaultAmt > 0) defaultAmt.toInt().toString() else "0")
      }
    }
  }

  // State for Direct Custom Player Award
  var directUserEmail by remember { mutableStateOf("") }
  var directPrizeAmountStr by remember { mutableStateOf("") }
  var directPrizeReason by remember { mutableStateOf("Winner Prize") }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 90.dp)
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = "MATCH RESULTS & PRIZES", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = TextPrimary)
          Text(text = tournament.title, style = MaterialTheme.typography.bodySmall, color = NeonCyan)
        }

        Button(
          onClick = onBack,
          colors = ButtonDefaults.buttonColors(containerColor = CarbonCardElevated),
          shape = RoundedCornerShape(8.dp)
        ) {
          Text("← Back", color = TextSecondary, fontSize = 12.sp)
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Prize Pool Rules Card
      Card(
        colors = CardDefaults.cardColors(containerColor = CarbonCard),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(12.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(text = "1st: ₹${tournament.firstPrize.toInt()}", color = EmeraldNeon, fontWeight = FontWeight.Bold, fontSize = 12.sp)
          Text(text = "2nd: ₹${tournament.secondPrize.toInt()}", color = AmberGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
          Text(text = "3rd: ₹${tournament.thirdPrize.toInt()}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
          Text(text = "Kill: ₹${tournament.perKillBonus.toInt()}", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // --- DIRECT PRIZE PAYOUT TOOL FOR ADMIN ---
      Card(
        colors = CardDefaults.cardColors(containerColor = CarbonCardElevated),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(EmeraldDark, EmeraldNeon))),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Payments, contentDescription = null, tint = EmeraldNeon, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "SELECT USER & SET CUSTOM PRIZE TO PAY",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Black,
              color = EmeraldNeon,
              letterSpacing = 0.5.sp
            )
          }

          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Select any player from registered teams or type their email, set custom prize amount, and pay them directly.",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            fontSize = 11.sp
          )

          Spacer(modifier = Modifier.height(12.dp))

          OutlinedTextField(
            value = directUserEmail,
            onValueChange = { directUserEmail = it },
            label = { Text("Player Email to Pay") },
            placeholder = { Text("e.g. gamer@gmail.com") },
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_direct_winner_email")
          )

          // Quick selection chips from registered players
          if (registrations.isNotEmpty()) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = "Registered Players (Tap to select):", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 10.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              registrations.take(4).forEach { reg ->
                Surface(
                  onClick = { directUserEmail = reg.userEmail },
                  shape = RoundedCornerShape(6.dp),
                  color = if (directUserEmail == reg.userEmail) EmeraldNeon else CarbonCard,
                  modifier = Modifier.padding(vertical = 2.dp)
                ) {
                  Text(
                    text = reg.playerIgn.ifBlank { reg.userEmail.substringBefore("@") },
                    color = if (directUserEmail == reg.userEmail) CarbonBackground else TextPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedTextField(
              value = directPrizeAmountStr,
              onValueChange = { if (it.all { ch -> ch.isDigit() }) directPrizeAmountStr = it },
              label = { Text("Prize (₹)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
              singleLine = true,
              modifier = Modifier.weight(1f).testTag("input_direct_prize_amount")
            )

            OutlinedTextField(
              value = directPrizeReason,
              onValueChange = { directPrizeReason = it },
              label = { Text("Prize Reason / Title") },
              colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
              singleLine = true,
              modifier = Modifier.weight(1.3f).testTag("input_direct_prize_reason")
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          Button(
            onClick = {
              val amt = directPrizeAmountStr.toDoubleOrNull() ?: 0.0
              if (directUserEmail.isBlank()) {
                Toast.makeText(context, "Please enter or select player email", Toast.LENGTH_SHORT).show()
                return@Button
              }
              if (amt <= 0.0) {
                Toast.makeText(context, "Please enter a valid prize amount", Toast.LENGTH_SHORT).show()
                return@Button
              }

              viewModel.awardCustomPrize(
                userEmail = directUserEmail.trim(),
                tournamentId = tournament.id,
                tournamentTitle = tournament.title,
                prizeAmount = amt,
                reason = directPrizeReason.ifBlank { "Match Winner Prize" },
                onSuccess = {
                  directPrizeAmountStr = ""
                  Toast.makeText(context, "₹${amt.toInt()} paid successfully to $directUserEmail!", Toast.LENGTH_LONG).show()
                }
              )
            },
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().height(46.dp).testTag("btn_direct_pay_winner")
          ) {
            Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("PAY THIS WINNER NOW", fontWeight = FontWeight.Black)
          }
        }
      }

      Spacer(modifier = Modifier.height(18.dp))
      Text(text = "REGISTERED PARTICIPANTS (${registrations.size})", style = MaterialTheme.typography.labelSmall, color = TextMuted)
      Spacer(modifier = Modifier.height(8.dp))
    }

    if (registrations.isEmpty()) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = CarbonCard),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = "No players registered in this match yet to distribute prizes.",
            modifier = Modifier.padding(20.dp),
            color = TextMuted
          )
        }
      }
    } else {
      items(registrations.size) { idx ->
        val reg = registrations[idx]
        val rank = ranks.getOrElse(idx) { 1 }
        val killCount = kills.getOrElse(idx) { 0 }
        val customPrizeText = customPrizes.getOrElse(idx) { "0" }
        val currentWin = customPrizeText.toDoubleOrNull() ?: 0.0

        Card(
          colors = CardDefaults.cardColors(containerColor = CarbonCard),
          border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(
              if (currentWin > 0) listOf(EmeraldDark, EmeraldNeon)
              else listOf(CarbonBorder, CarbonBorder)
            )
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(text = reg.teamName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text(text = "IGN: ${reg.playerIgn} • UID: ${reg.playerUid}", style = MaterialTheme.typography.bodySmall, color = EmeraldNeon, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(text = "Email: ${reg.userEmail}", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 10.sp)
              }
              Column(horizontalAlignment = Alignment.End) {
                Text(text = "SET PRIZE", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
                Text(
                  text = "₹${currentWin.toInt()}",
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Black,
                  fontSize = 18.sp,
                  color = if (currentWin > 0) EmeraldNeon else TextMuted
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Inputs for Rank, Kills and Custom Prize Amount
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              OutlinedTextField(
                value = rank.toString(),
                onValueChange = {
                  val newRank = it.toIntOrNull() ?: 1
                  if (idx < ranks.size) {
                    ranks[idx] = newRank
                    // Auto recalculate suggestion if not manually set
                    val placement = when (newRank) {
                      1 -> tournament.firstPrize
                      2 -> tournament.secondPrize
                      3 -> tournament.thirdPrize
                      else -> 0.0
                    }
                    if (idx < customPrizes.size) {
                      customPrizes[idx] = (placement + (killCount * tournament.perKillBonus)).toInt().toString()
                    }
                  }
                },
                label = { Text("Rank (#)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                singleLine = true,
                modifier = Modifier
                  .weight(0.9f)
                  .testTag("input_rank_$idx")
              )

              OutlinedTextField(
                value = killCount.toString(),
                onValueChange = {
                  val newKills = it.toIntOrNull() ?: 0
                  if (idx < kills.size) {
                    kills[idx] = newKills
                    val placement = when (rank) {
                      1 -> tournament.firstPrize
                      2 -> tournament.secondPrize
                      3 -> tournament.thirdPrize
                      else -> 0.0
                    }
                    if (idx < customPrizes.size) {
                      customPrizes[idx] = (placement + (newKills * tournament.perKillBonus)).toInt().toString()
                    }
                  }
                },
                label = { Text("Kills") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                singleLine = true,
                modifier = Modifier
                  .weight(0.9f)
                  .testTag("input_kills_$idx")
              )

              // ADMIN CUSTOM PRIZE INPUT (CAN SET ANY AMOUNT)
              OutlinedTextField(
                value = customPrizeText,
                onValueChange = { if (it.all { ch -> ch.isDigit() }) if (idx < customPrizes.size) customPrizes[idx] = it },
                label = { Text("Prize (₹)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AmberGold, unfocusedBorderColor = CarbonBorder, focusedTextColor = AmberGold, unfocusedTextColor = TextPrimary),
                singleLine = true,
                modifier = Modifier
                  .weight(1.2f)
                  .testTag("input_custom_prize_$idx")
              )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick button to pay this winner directly
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.End
            ) {
              OutlinedButton(
                onClick = {
                  val prizeToPay = customPrizeText.toDoubleOrNull() ?: 0.0
                  if (prizeToPay <= 0) {
                    Toast.makeText(context, "Set prize amount first", Toast.LENGTH_SHORT).show()
                    return@OutlinedButton
                  }
                  viewModel.awardCustomPrize(
                    userEmail = reg.userEmail,
                    tournamentId = tournament.id,
                    tournamentTitle = tournament.title,
                    prizeAmount = prizeToPay,
                    reason = "Match Prize (Rank #$rank, $killCount kills)",
                    onSuccess = {
                      Toast.makeText(context, "₹${prizeToPay.toInt()} sent to ${reg.playerIgn}!", Toast.LENGTH_SHORT).show()
                    }
                  )
                },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = EmeraldNeon),
                border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(EmeraldDark, EmeraldNeon))),
                shape = RoundedCornerShape(8.dp)
              ) {
                Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Pay ₹${currentWin.toInt()} to ${reg.playerIgn} Now", fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }

      item {
        Spacer(modifier = Modifier.height(20.dp))
        Button(
          onClick = {
            val updatedRegistrations = registrations.mapIndexed { i, reg ->
              val r = ranks.getOrElse(i) { 1 }
              val k = kills.getOrElse(i) { 0 }
              val won = customPrizes.getOrElse(i) { "0" }.toDoubleOrNull() ?: 0.0
              reg.copy(
                placementRank = r,
                kills = k,
                prizeWon = won
              )
            }
            onSubmitPrizes(updatedRegistrations)
          },
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("btn_distribute_prizes_payout")
        ) {
          Icon(Icons.Default.EmojiEvents, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "1-CLICK DISTRIBUTE ALL CUSTOM PRIZES", fontWeight = FontWeight.Black)
        }
      }
    }
  }
}
