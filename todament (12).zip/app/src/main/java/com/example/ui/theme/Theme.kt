package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TodamentColorScheme = darkColorScheme(
  primary = EmeraldNeon,
  onPrimary = CarbonBackground,
  primaryContainer = EmeraldDark,
  onPrimaryContainer = TextPrimary,
  secondary = NeonCyan,
  onSecondary = CarbonBackground,
  secondaryContainer = Color(0xFF004D5A),
  onSecondaryContainer = TextPrimary,
  tertiary = AmberGold,
  onTertiary = CarbonBackground,
  background = CarbonBackground,
  onBackground = TextPrimary,
  surface = CarbonSurface,
  onSurface = TextPrimary,
  surfaceVariant = CarbonCard,
  onSurfaceVariant = TextSecondary,
  outline = CarbonBorder,
  error = CrimsonAlert,
  onError = Color.White
)

@Composable
fun TodamentTheme(
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = TodamentColorScheme,
    typography = Typography,
    content = content
  )
}

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit
) {
  TodamentTheme(content = content)
}
