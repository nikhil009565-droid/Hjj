package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.AiModelOption
import com.example.data.ai.TodamentAiCoachService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

data class ChatMessage(
  val id: String = UUID.randomUUID().toString(),
  val text: String,
  val isFromUser: Boolean,
  val timestamp: Long = System.currentTimeMillis(),
  val isStreaming: Boolean = false
)

class AiChatViewModel(
  private val aiService: TodamentAiCoachService = TodamentAiCoachService()
) : ViewModel() {

  private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
  val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

  private val _selectedModel = MutableStateFlow(AiModelOption.FLASH_GENERAL)
  val selectedModel: StateFlow<AiModelOption> = _selectedModel.asStateFlow()

  private val _isGenerating = MutableStateFlow(false)
  val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

  private val _errorMessage = MutableStateFlow<String?>(null)
  val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

  val suggestedPrompts = listOf(
    "🔥 Best weapon combos for Bermuda?",
    "🏆 How are tournament prizes distributed?",
    "💳 How do UPI deposits & UTR work?",
    "⚡ Clash Squad rush & zone strategies",
    "🛡️ What are the custom room rules?"
  )

  init {
    // Initial welcome message from Coach
    _messages.value = listOf(
      ChatMessage(
        text = "Hey champion! 👋 I'm your **TODAMENT AI Esports Coach & Support**.\n\n" +
            "Ask me anything about:\n" +
            "• **Free Fire Tactics** (weapon combos, map rotations, clutch plays)\n" +
            "• **Tournament Rules & Room IDs** (match schedules, formats)\n" +
            "• **Wallet & Payouts** (UPI deposits, 12-digit UTR, withdrawals)\n\n" +
            "What do you want to master today? 🚀",
        isFromUser = false
      )
    )
  }

  fun setModel(model: AiModelOption) {
    _selectedModel.value = model
  }

  fun clearError() {
    _errorMessage.value = null
  }

  fun clearHistory() {
    _messages.value = listOf(
      ChatMessage(
        text = "Chat cleared! How can I help you in the arena today? 🎯",
        isFromUser = false
      )
    )
  }

  fun sendMessage(prompt: String) {
    val cleanPrompt = prompt.trim()
    if (cleanPrompt.isEmpty() || _isGenerating.value) return

    val userMsg = ChatMessage(text = cleanPrompt, isFromUser = true)
    val assistantPlaceholderId = UUID.randomUUID().toString()
    val assistantPlaceholder = ChatMessage(
      id = assistantPlaceholderId,
      text = "",
      isFromUser = false,
      isStreaming = true
    )

    // Current conversation history excluding initial welcome
    val currentHistory = _messages.value
      .filter { it.text.isNotBlank() }
      .map { Pair(it.text, it.isFromUser) }

    _messages.value = _messages.value + userMsg + assistantPlaceholder
    _isGenerating.value = true
    _errorMessage.value = null

    viewModelScope.launch {
      val accumulated = StringBuilder()
      try {
        aiService.sendChatStream(
          history = currentHistory,
          userMessage = cleanPrompt,
          modelOption = _selectedModel.value
        ).collect { chunk ->
          accumulated.append(chunk)
          val updatedList = _messages.value.map { msg ->
            if (msg.id == assistantPlaceholderId) {
              msg.copy(text = accumulated.toString(), isStreaming = true)
            } else msg
          }
          _messages.value = updatedList
        }

        // Finalize completed message
        _messages.value = _messages.value.map { msg ->
          if (msg.id == assistantPlaceholderId) {
            msg.copy(text = accumulated.toString(), isStreaming = false)
          } else msg
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        val errorMsg = e.localizedMessage ?: "Failed to get AI response"
        _errorMessage.value = errorMsg
        _messages.value = _messages.value.map { msg ->
          if (msg.id == assistantPlaceholderId) {
            msg.copy(
              text = "⚠️ Couldn't generate response: $errorMsg\n\nPlease check your internet connection or try again.",
              isStreaming = false
            )
          } else msg
        }
      } finally {
        _isGenerating.value = false
      }
    }
  }
}
