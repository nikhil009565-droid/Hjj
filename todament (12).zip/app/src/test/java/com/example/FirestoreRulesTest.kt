package com.example

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.UUID

class FirestoreRulesTest : FirestoreEmulatorTestBase() {

  @Test
  fun publicTournaments_canRead(): Unit = runBlocking {
    signInTestUser("operator@gmail.com")
    val docId = "tourn_${UUID.randomUUID()}"
    val docRef = firestore.collection("tournaments").document(docId)

    val payload = hashMapOf<String, Any>(
      "id" to docId,
      "title" to "Free Fire Solo Scrims",
      "entryFee" to 20.0,
      "prizePool" to 200.0
    )
    withTimeout(5000L) {
      docRef.set(payload).await()
    }

    // Sign out to verify public unauthenticated read
    auth.signOut()
    withTimeout(5000L) {
      val snapshot = docRef.get().await()
      assertTrue(snapshot.exists())
      assertEquals("Free Fire Solo Scrims", snapshot.getString("title"))
    }
  }

  @Test
  fun appSettings_public_canRead(): Unit = runBlocking {
    signInTestUser("firefree60510@gmail.com")
    val settingsDoc = firestore.collection("app_settings").document("global_config")
    val payload = hashMapOf<String, Any>(
      "id" to "global_config",
      "telegramHelpUrl" to "https://t.me/todament_support"
    )
    withTimeout(5000L) {
      settingsDoc.set(payload).await()
    }

    // Sign out to verify public read
    auth.signOut()
    withTimeout(5000L) {
      val snapshot = settingsDoc.get().await()
      assertTrue(snapshot.exists())
    }
  }

  @Test
  fun userProfile_canReadAndWrite(): Unit = runBlocking {
    val uid = signInTestUser("gamer1@gmail.com")
    val userDoc = firestore.collection("users").document(uid)

    val userData = hashMapOf<String, Any>(
      "userId" to uid,
      "email" to "gamer1@gmail.com",
      "freeFireUid" to "12345678",
      "freeFireIgn" to "HEADSHOT_KING",
      "walletBalance" to 500.0
    )

    withTimeout(5000L) {
      userDoc.set(userData).await()
      val snapshot = userDoc.get().await()
      assertTrue(snapshot.exists())
      assertEquals("HEADSHOT_KING", snapshot.getString("freeFireIgn"))
    }
  }

  @Test
  fun users_list_unauthenticated_failsWithPermissionDenied(): Unit = runBlocking {
    auth.signOut()
    try {
      withTimeout(5000L) {
        firestore.collection("users").get().await()
      }
      fail("Expected PERMISSION_DENIED on users list")
    } catch (e: Exception) {
      val firestoreException = e.unwrapFirestoreException()
      assertTrue(
        "Expected PERMISSION_DENIED but got $e",
        firestoreException?.code == FirebaseFirestoreException.Code.PERMISSION_DENIED ||
            e is FirebaseFirestoreException && e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED
      )
    }
  }

  @Test
  fun deleteTournament_nonAdmin_failsWithPermissionDenied(): Unit = runBlocking {
    signInTestUser("operator@gmail.com")
    val docId = "tourn_${UUID.randomUUID()}"
    val docRef = firestore.collection("tournaments").document(docId)
    val payload = hashMapOf<String, Any>(
      "id" to docId,
      "title" to "Protected Tournament",
      "entryFee" to 10.0,
      "prizePool" to 100.0
    )
    withTimeout(5000L) {
      docRef.set(payload).await()
    }

    signInTestUser("normal_user@gmail.com")
    try {
      withTimeout(5000L) {
        docRef.delete().await()
      }
      fail("Expected PERMISSION_DENIED on delete tournament")
    } catch (e: Exception) {
      val firestoreException = e.unwrapFirestoreException()
      assertTrue(
        "Expected PERMISSION_DENIED but got $e",
        firestoreException?.code == FirebaseFirestoreException.Code.PERMISSION_DENIED ||
            e is FirebaseFirestoreException && e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED
      )
    }
  }
}
