package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.Tournament
import com.example.data.repository.TodamentRepository
import com.example.ui.components.TodamentHeader
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ReferScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.TournamentsScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.screens.admin.AdminSuiteScreen
import com.example.ui.theme.CarbonBackground
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonCard
import com.example.ui.theme.CarbonCardElevated
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TodamentTheme
import com.example.ui.viewmodel.TodamentViewModel

import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.outlined.AutoAwesome
import com.example.ui.screens.AiChatScreen

enum class AppScreen(
  val label: String,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector
) {
  HOME("Home", Icons.Filled.Home, Icons.Outlined.Home),
  TOURNAMENTS("Scrims", Icons.Filled.SportsEsports, Icons.Outlined.SportsEsports),
  AI_CHAT("AI Coach", Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome),
  WALLET("Wallet", Icons.Filled.AccountBalanceWallet, Icons.Outlined.AccountBalanceWallet),
  REFER("Refer", Icons.Filled.CardGiftcard, Icons.Outlined.CardGiftcard),
  PROFILE("Profile", Icons.Filled.Person, Icons.Outlined.Person),
  ADMIN_SUITE("Admin", Icons.Filled.Person, Icons.Outlined.Person),
  AUTH("Auth", Icons.Filled.Person, Icons.Outlined.Person)
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    com.example.util.configureAppCheck(this, intent)
    enableEdgeToEdge()
    setContent {
      TodamentTheme {
        TodamentApp()
      }
    }
  }
}

@Composable
fun TodamentApp(
  viewModel: TodamentViewModel = viewModel()
) {
  val context = LocalContext.current
  val currentUser by viewModel.currentUser.collectAsState()
  val uiMessage by viewModel.uiMessage.collectAsState()
  val errorMessage by viewModel.errorMessage.collectAsState()

  var currentScreen by remember { mutableStateOf(AppScreen.HOME) }
  var selectedTournamentForDetail by remember { mutableStateOf<Tournament?>(null) }
  val snackbarHostState = remember { SnackbarHostState() }

  // Check if logged in
  val isLoggedIn = currentUser != null

  // Handle toasts/snackbars
  LaunchedEffect(uiMessage) {
    uiMessage?.let {
      snackbarHostState.showSnackbar(it)
      viewModel.clearMessages()
    }
  }

  LaunchedEffect(errorMessage) {
    errorMessage?.let {
      snackbarHostState.showSnackbar(it)
      viewModel.clearMessages()
    }
  }

  // Back Press Handling for secondary screens
  BackHandler(enabled = currentScreen != AppScreen.HOME) {
    if (currentScreen == AppScreen.ADMIN_SUITE) {
      currentScreen = AppScreen.PROFILE
    } else {
      currentScreen = AppScreen.HOME
    }
  }

  var showSplash by remember { mutableStateOf(true) }
  val isAdmin = currentUser?.isAdmin == true || currentUser?.email?.equals(TodamentRepository.SUPER_ADMIN_EMAIL, ignoreCase = true) == true

  if (showSplash) {
    SplashScreen(onFinish = { showSplash = false })
    return
  }

  if (!isLoggedIn) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
    ) {
      AuthScreen(
        viewModel = viewModel,
        onAuthSuccess = {
          currentScreen = AppScreen.HOME
        }
      )
    }
    return
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    containerColor = CarbonBackground,
    topBar = {
      if (currentScreen != AppScreen.ADMIN_SUITE && currentScreen != AppScreen.AUTH && currentScreen != AppScreen.AI_CHAT) {
        Column(modifier = Modifier.statusBarsPadding()) {
          TodamentHeader(
            userName = currentUser?.fullName,
            userIgn = currentUser?.freeFireIgn,
            balance = currentUser?.walletBalance ?: 0.0,
            isAdmin = isAdmin,
            onWalletClick = { currentScreen = AppScreen.WALLET },
            onAdminClick = { currentScreen = AppScreen.ADMIN_SUITE },
            onAiCoachClick = { currentScreen = AppScreen.AI_CHAT }
          )
        }
      }
    },
    bottomBar = {
      if (currentScreen != AppScreen.ADMIN_SUITE && currentScreen != AppScreen.AUTH && currentScreen != AppScreen.AI_CHAT) {
        Surface(
          color = CarbonSurface,
          tonalElevation = 10.dp,
          shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
          border = BorderStroke(1.dp, CarbonBorder),
          modifier = Modifier
            .navigationBarsPadding()
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .testTag("bottom_nav_bar")
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 4.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
          ) {
            // Tab 1: Home
            BottomNavTab(
              label = "Home",
              icon = if (currentScreen == AppScreen.HOME) Icons.Filled.Home else Icons.Outlined.Home,
              isSelected = currentScreen == AppScreen.HOME,
              onClick = { currentScreen = AppScreen.HOME },
              modifier = Modifier.weight(1f),
              testTag = "nav_item_home"
            )

            // Tab 2: Matches
            BottomNavTab(
              label = "Matches",
              icon = if (currentScreen == AppScreen.TOURNAMENTS) Icons.Filled.SportsEsports else Icons.Outlined.SportsEsports,
              isSelected = currentScreen == AppScreen.TOURNAMENTS,
              onClick = {
                selectedTournamentForDetail = null
                currentScreen = AppScreen.TOURNAMENTS
              },
              modifier = Modifier.weight(1f),
              testTag = "nav_item_matches"
            )

            // Tab 3: CENTER CIRCULAR "GOLA" - GEMINI AI COACH
            Box(
              modifier = Modifier
                .weight(1.2f)
                .padding(vertical = 2.dp),
              contentAlignment = Alignment.Center
            ) {
              Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                  .clickable { currentScreen = AppScreen.AI_CHAT }
                  .testTag("btn_menu_gemini_gola")
              ) {
                Box(
                  modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(
                      brush = Brush.linearGradient(
                        listOf(EmeraldNeon, NeonCyan, Color(0xFF8A2BE2))
                      )
                    )
                    .border(
                      width = if (currentScreen == AppScreen.AI_CHAT) 3.dp else 2.dp,
                      color = if (currentScreen == AppScreen.AI_CHAT) Color.White else EmeraldNeon,
                      shape = CircleShape
                    )
                    .padding(2.dp),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = "Gemini AI Coach Gola",
                    tint = CarbonBackground,
                    modifier = Modifier.size(26.dp)
                  )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = "AI BOT",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Black,
                  letterSpacing = 0.5.sp,
                  color = if (currentScreen == AppScreen.AI_CHAT) EmeraldNeon else NeonCyan
                )
              }
            }

            // Tab 4: Wallet
            BottomNavTab(
              label = "Wallet",
              icon = if (currentScreen == AppScreen.WALLET) Icons.Filled.AccountBalanceWallet else Icons.Outlined.AccountBalanceWallet,
              isSelected = currentScreen == AppScreen.WALLET,
              onClick = { currentScreen = AppScreen.WALLET },
              modifier = Modifier.weight(1f),
              testTag = "nav_item_wallet"
            )

            // Tab 5: Profile
            BottomNavTab(
              label = "Profile",
              icon = if (currentScreen == AppScreen.PROFILE) Icons.Filled.Person else Icons.Outlined.Person,
              isSelected = currentScreen == AppScreen.PROFILE,
              onClick = { currentScreen = AppScreen.PROFILE },
              modifier = Modifier.weight(1f),
              testTag = "nav_item_profile"
            )
          }
        }
      }
    },
    snackbarHost = {
      SnackbarHost(
        hostState = snackbarHostState,
        modifier = Modifier.padding(bottom = 80.dp)
      )
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      when (currentScreen) {
        AppScreen.HOME -> {
          HomeScreen(
            viewModel = viewModel,
            onNavigateToTournaments = { currentScreen = AppScreen.TOURNAMENTS },
            onNavigateToWallet = { currentScreen = AppScreen.WALLET },
            onNavigateToRefer = { currentScreen = AppScreen.REFER },
            onSelectTournament = { tourn ->
              selectedTournamentForDetail = tourn
              currentScreen = AppScreen.TOURNAMENTS
            },
            onNavigateToAiCoach = { currentScreen = AppScreen.AI_CHAT }
          )
        }

        AppScreen.TOURNAMENTS -> {
          TournamentsScreen(
            viewModel = viewModel,
            onNavigateToWallet = { currentScreen = AppScreen.WALLET },
            selectedTournamentFromHome = selectedTournamentForDetail
          )
        }

        AppScreen.WALLET -> {
          WalletScreen(viewModel = viewModel)
        }

        AppScreen.REFER -> {
          ReferScreen(viewModel = viewModel)
        }

        AppScreen.PROFILE -> {
          ProfileScreen(
            viewModel = viewModel,
            onNavigateToAdmin = { currentScreen = AppScreen.ADMIN_SUITE },
            onNavigateToWallet = { currentScreen = AppScreen.WALLET },
            onLogout = { currentScreen = AppScreen.AUTH },
            onNavigateToRefer = { currentScreen = AppScreen.REFER }
          )
        }

        AppScreen.ADMIN_SUITE -> {
          AdminSuiteScreen(
            viewModel = viewModel,
            onNavigateBack = { currentScreen = AppScreen.PROFILE }
          )
        }

        AppScreen.AI_CHAT -> {
          AiChatScreen(
            onNavigateBack = { currentScreen = AppScreen.HOME }
          )
        }

        AppScreen.AUTH -> {
          AuthScreen(
            viewModel = viewModel,
            onAuthSuccess = { currentScreen = AppScreen.HOME }
          )
        }
      }
    }
  }
}

@Composable
private fun BottomNavTab(
  label: String,
  icon: ImageVector,
  isSelected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  testTag: String = ""
) {
  Column(
    modifier = modifier
      .clip(RoundedCornerShape(12.dp))
      .clickable(onClick = onClick)
      .padding(vertical = 4.dp)
      .testTag(testTag),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Box(
      modifier = Modifier
        .clip(RoundedCornerShape(10.dp))
        .background(if (isSelected) EmeraldNeon.copy(alpha = 0.15f) else Color.Transparent)
        .padding(horizontal = 10.dp, vertical = 4.dp),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint = if (isSelected) EmeraldNeon else TextSecondary,
        modifier = Modifier.size(22.dp)
      )
    }
    Spacer(modifier = Modifier.height(2.dp))
    Text(
      text = label,
      fontSize = 11.sp,
      fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal,
      color = if (isSelected) EmeraldNeon else TextMuted
    )
  }
}
