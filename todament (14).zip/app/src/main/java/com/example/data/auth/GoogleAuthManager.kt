package com.example.data.auth

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.util.Base64
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONObject

class GoogleAuthManager(private val context: Context) {
  private val credentialManager = CredentialManager.create(context)

  companion object {
    fun findActivity(context: Context): Activity? {
      var ctx = context
      while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
      }
      return null
    }
  }

  fun signInWithGoogle(
    activity: Activity,
    scope: CoroutineScope,
    onSuccess: (email: String, displayName: String) -> Unit,
    onError: (String) -> Unit,
    onCancelled: () -> Unit = {}
  ) {
    val clientId = try {
      context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
      onError("Google Sign-In configuration missing: default_web_client_id not found")
      return
    }

    // Official interactive Google Sign-In option from Credential Manager
    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()

    val request = GetCredentialRequest.Builder()
      .addCredentialOption(signInOption)
      .build()

    scope.launch {
      try {
        val result = credentialManager.getCredential(activity, request)
        val credential = result.credential
        if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
          val googleIdTokenObj = GoogleIdTokenCredential.createFrom(credential.data)
          val idToken = googleIdTokenObj.idToken

          // Extract verified email and name directly from Google ID Token JWT payload
          val (jwtEmail, jwtName) = parseJwtPayload(idToken)
          var email = jwtEmail ?: if (googleIdTokenObj.id.contains("@")) googleIdTokenObj.id else ""
          var displayName = jwtName ?: googleIdTokenObj.displayName ?: email.substringBefore("@")

          try {
            val authCredential = GoogleAuthProvider.getCredential(idToken, null)
            val authResult = Firebase.auth.signInWithCredential(authCredential).await()
            val firebaseUser = authResult.user
            if (!firebaseUser?.email.isNullOrBlank()) {
              email = firebaseUser!!.email!!
            }
            if (!firebaseUser?.displayName.isNullOrBlank()) {
              displayName = firebaseUser!!.displayName!!
            }
          } catch (firebaseEx: Exception) {
            Log.w("Auth", "Firebase auth sync: ${firebaseEx.message}; using device verified Google token")
          }

          if (email.isNotBlank() && email.contains("@")) {
            onSuccess(email.trim().lowercase(), displayName.ifBlank { email.substringBefore("@") })
          } else {
            onError("Could not obtain verified email from selected Google account.")
          }
        } else {
          onError("Unexpected credential format returned from Google.")
        }
      } catch (e: GetCredentialCancellationException) {
        Log.w("Auth", "Google Sign-In flow dismissed by user")
        onCancelled()
      } catch (e: Exception) {
        Log.e("Auth", "Google Sign-In failed", e)
        onError(e.localizedMessage ?: "Google Sign-In failed")
      }
    }
  }

  private fun parseJwtPayload(idToken: String): Pair<String?, String?> {
    return try {
      val parts = idToken.split(".")
      if (parts.size >= 2) {
        val bytes = Base64.decode(parts[1], Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
        val json = JSONObject(String(bytes, Charsets.UTF_8))
        val email = json.optString("email").takeIf { it.isNotBlank() && it.contains("@") }
        val name = json.optString("name").takeIf { it.isNotBlank() }
        Pair(email, name)
      } else {
        Pair(null, null)
      }
    } catch (e: Exception) {
      Log.w("Auth", "Failed to parse JWT payload", e)
      Pair(null, null)
    }
  }

  fun signOut(scope: CoroutineScope, onComplete: () -> Unit) {
    Firebase.auth.signOut()
    scope.launch {
      try {
        credentialManager.clearCredentialState(ClearCredentialStateRequest())
      } catch (e: Exception) {
        Log.e("Auth", "Failed to clear credential state", e)
      } finally {
        onComplete()
      }
    }
  }
}
