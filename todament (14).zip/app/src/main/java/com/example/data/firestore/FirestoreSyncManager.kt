package com.example.data.firestore

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.model.AppSettings
import com.example.data.model.DepositRequest
import com.example.data.model.MatchFormat
import com.example.data.model.MatchStatus
import com.example.data.model.Registration
import com.example.data.model.RequestStatus
import com.example.data.model.Tournament
import com.example.data.model.TransactionType
import com.example.data.model.User
import com.example.data.model.WalletTransaction
import com.example.data.model.WithdrawalRequest
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class FirestoreSyncManager(
  private val context: Context,
  private val database: AppDatabase
) {
  private val db: FirebaseFirestore by lazy {
    try {
      val customDbId = context.applicationContext.getString(R.string.firestore_database_id)
      if (customDbId.isNotBlank()) {
        FirebaseFirestore.getInstance(customDbId)
      } else {
        FirebaseFirestore.getInstance()
      }
    } catch (e: Exception) {
      Log.w(TAG, "Named Firestore instance failed, falling back to default", e)
      FirebaseFirestore.getInstance()
    }
  }

  private var tournamentsListener: ListenerRegistration? = null
  private var settingsListener: ListenerRegistration? = null
  private var usersListener: ListenerRegistration? = null
  private var registrationsListener: ListenerRegistration? = null
  private var depositsListener: ListenerRegistration? = null
  private var withdrawalsListener: ListenerRegistration? = null
  private var transactionsListener: ListenerRegistration? = null

  companion object {
    private const val TAG = "FirestoreSync"

    fun emailToDocId(email: String): String {
      return email.lowercase().trim().replace(".", "_").replace("@", "_at_")
    }
  }

  fun startRealtimeSync(scope: CoroutineScope) {
    try {
      // 1. Sync global app settings in real-time
      val settingsDoc = db.collection("app_settings").document("global_config")
      settingsListener = settingsDoc.addSnapshotListener { snapshot, error ->
        if (error != null) {
          handleFirestoreError(error, OperationType.GET, settingsDoc.path)
          return@addSnapshotListener
        }
        if (snapshot != null && snapshot.exists()) {
          val data = snapshot.data ?: return@addSnapshotListener
          scope.launch(Dispatchers.IO) {
            val existing = database.appConfigDao().getSettingsSync() ?: AppSettings()
            val updated = existing.copy(
              adminUpiId = data["adminUpiId"] as? String ?: existing.adminUpiId,
              adminPayeeName = data["adminPayeeName"] as? String ?: existing.adminPayeeName,
              telegramHelpUrl = data["telegramHelpUrl"] as? String ?: existing.telegramHelpUrl,
              qrCodeImageUri = data["qrCodeImageUri"] as? String ?: existing.qrCodeImageUri,
              supportContact = data["supportContact"] as? String ?: existing.supportContact,
              announcementNotice = data["announcementNotice"] as? String ?: existing.announcementNotice,
              minDepositAmount = (data["minDepositAmount"] as? Number)?.toDouble() ?: existing.minDepositAmount,
              minWithdrawalAmount = (data["minWithdrawalAmount"] as? Number)?.toDouble() ?: existing.minWithdrawalAmount,
              isSampleDataSeeded = data["isSampleDataSeeded"] as? Boolean ?: existing.isSampleDataSeeded
            )
            database.appConfigDao().saveSettings(updated)
            Log.d(TAG, "Synced AppSettings from Firestore successfully")
          }
        }
      }

      // 2. Sync tournaments in real-time
      val tournamentsCol = db.collection("tournaments")
      tournamentsListener = tournamentsCol.addSnapshotListener { snapshots, error ->
        if (error != null) {
          handleFirestoreError(error, OperationType.LIST, tournamentsCol.path)
          return@addSnapshotListener
        }
        if (snapshots != null) {
          scope.launch(Dispatchers.IO) {
            for (change in snapshots.documentChanges) {
              if (change.type == DocumentChange.Type.REMOVED) {
                database.tournamentDao().deleteTournamentById(change.document.id)
                Log.d(TAG, "Removed deleted tournament ${change.document.id} from local Room cache")
              }
            }
            for (doc in snapshots.documents) {
              val data = doc.data ?: continue
              val id = doc.id
              val title = data["title"] as? String ?: continue
              val mapName = data["mapName"] as? String ?: "Bermuda"
              val formatStr = data["format"] as? String ?: "SOLO"
              val format = try {
                MatchFormat.valueOf(formatStr)
              } catch (e: Exception) {
                MatchFormat.SOLO
              }
              val statusStr = data["status"] as? String ?: "OPEN"
              val status = try {
                MatchStatus.valueOf(statusStr)
              } catch (e: Exception) {
                MatchStatus.OPEN
              }
              val entryFee = (data["entryFee"] as? Number)?.toDouble() ?: 0.0
              val totalPrizePool = (data["totalPrizePool"] as? Number)?.toDouble() ?: 0.0
              val firstPrize = (data["firstPrize"] as? Number)?.toDouble() ?: 0.0
              val secondPrize = (data["secondPrize"] as? Number)?.toDouble() ?: 0.0
              val thirdPrize = (data["thirdPrize"] as? Number)?.toDouble() ?: 0.0
              val perKillBonus = (data["perKillBonus"] as? Number)?.toDouble() ?: 0.0
              val matchDate = data["matchDate"] as? String ?: ""
              val startTime = data["startTime"] as? String ?: ""
              val regClose = data["registrationClosingTime"] as? String ?: ""
              val matchTimestamp = (data["matchTimestamp"] as? Number)?.toLong() ?: System.currentTimeMillis()
              val totalSlots = (data["totalSlots"] as? Number)?.toInt() ?: 48
              val filledSlots = (data["filledSlots"] as? Number)?.toInt() ?: 0
              val customRules = data["customRules"] as? String ?: ""
              val roomId = data["roomId"] as? String ?: ""
              val roomPassword = data["roomPassword"] as? String ?: ""
              val isRoomVisible = data["isRoomVisible"] as? Boolean ?: false

              val tourn = Tournament(
                id = id,
                title = title,
                mapName = mapName,
                format = format,
                entryFee = entryFee,
                totalPrizePool = totalPrizePool,
                firstPrize = firstPrize,
                secondPrize = secondPrize,
                thirdPrize = thirdPrize,
                perKillBonus = perKillBonus,
                matchDate = matchDate,
                startTime = startTime,
                registrationClosingTime = regClose,
                matchTimestamp = matchTimestamp,
                totalSlots = totalSlots,
                filledSlots = filledSlots,
                status = status,
                customRules = customRules,
                roomId = roomId,
                roomPassword = roomPassword,
                isRoomVisible = isRoomVisible
              )
              database.tournamentDao().insertTournament(tourn)
            }
            Log.d(TAG, "Synced ${snapshots.size()} tournaments from Firestore")
          }
        }
      }

      // 3. Sync all users in real-time (Ensures all accounts persist across updates & multiple devices)
      val usersCol = db.collection("users")
      usersListener = usersCol.addSnapshotListener { snapshots, error ->
        if (error != null) {
          handleFirestoreError(error, OperationType.LIST, usersCol.path)
          return@addSnapshotListener
        }
        if (snapshots != null) {
          scope.launch(Dispatchers.IO) {
            for (doc in snapshots.documents) {
              val data = doc.data ?: continue
              val email = data["email"] as? String ?: continue
              val existingUser = database.userDao().getUserSync(email)
              val user = User(
                email = email,
                fullName = data["fullName"] as? String ?: existingUser?.fullName ?: "",
                phoneNumber = data["phoneNumber"] as? String ?: existingUser?.phoneNumber ?: "",
                freeFireUid = data["freeFireUid"] as? String ?: existingUser?.freeFireUid ?: "",
                freeFireIgn = data["freeFireIgn"] as? String ?: existingUser?.freeFireIgn ?: "",
                referralCode = data["referralCode"] as? String ?: existingUser?.referralCode ?: "",
                referredByCode = data["referredByCode"] as? String ?: existingUser?.referredByCode ?: "",
                password = data["password"] as? String ?: existingUser?.password ?: "",
                walletBalance = (data["walletBalance"] as? Number)?.toDouble() ?: existingUser?.walletBalance ?: 0.0,
                totalDeposited = (data["totalDeposited"] as? Number)?.toDouble() ?: existingUser?.totalDeposited ?: 0.0,
                totalWinnings = (data["totalWinnings"] as? Number)?.toDouble() ?: existingUser?.totalWinnings ?: 0.0,
                totalWithdrawn = (data["totalWithdrawn"] as? Number)?.toDouble() ?: existingUser?.totalWithdrawn ?: 0.0,
                reservedForWithdrawal = (data["reservedForWithdrawal"] as? Number)?.toDouble() ?: existingUser?.reservedForWithdrawal ?: 0.0,
                isAdmin = data["isAdmin"] as? Boolean ?: existingUser?.isAdmin ?: false,
                createdAt = (data["createdAt"] as? Number)?.toLong() ?: existingUser?.createdAt ?: System.currentTimeMillis()
              )
              database.userDao().insertUser(user)
            }
            Log.d(TAG, "Synced ${snapshots.size()} users from Firestore")
          }
        }
      }

      // 4. Sync registrations in real-time (Ensures registered players show across devices & match counts stay accurate)
      val regCol = db.collection("registrations")
      registrationsListener = regCol.addSnapshotListener { snapshots, error ->
        if (error != null) {
          handleFirestoreError(error, OperationType.LIST, regCol.path)
          return@addSnapshotListener
        }
        if (snapshots != null) {
          scope.launch(Dispatchers.IO) {
            for (doc in snapshots.documents) {
              val data = doc.data ?: continue
              val id = doc.id
              val tournamentId = data["tournamentId"] as? String ?: continue
              val userEmail = data["userEmail"] as? String ?: continue
              val teamName = data["teamName"] as? String ?: ""
              val playerIgn = data["playerIgn"] as? String ?: ""
              val playerUid = data["playerUid"] as? String ?: ""
              val teammatesJson = data["teammatesJson"] as? String ?: ""
              val entryFeePaid = (data["entryFeePaid"] as? Number)?.toDouble() ?: 0.0
              val registeredAt = (data["registeredAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
              val kills = (data["kills"] as? Number)?.toInt() ?: 0
              val placementRank = (data["placementRank"] as? Number)?.toInt() ?: 0
              val prizeWon = (data["prizeWon"] as? Number)?.toDouble() ?: 0.0

              val reg = Registration(
                id = id,
                tournamentId = tournamentId,
                userEmail = userEmail,
                teamName = teamName,
                playerIgn = playerIgn,
                playerUid = playerUid,
                teammatesJson = teammatesJson,
                entryFeePaid = entryFeePaid,
                registeredAt = registeredAt,
                kills = kills,
                placementRank = placementRank,
                prizeWon = prizeWon
              )
              database.registrationDao().insertRegistration(reg)
            }
            Log.d(TAG, "Synced ${snapshots.size()} registrations from Firestore")
          }
        }
      }

      // 5. Sync deposit requests in real-time (Ensures deposits visible to admin & status updates visible to user)
      val depCol = db.collection("deposit_requests")
      depositsListener = depCol.addSnapshotListener { snapshots, error ->
        if (error != null) {
          handleFirestoreError(error, OperationType.LIST, depCol.path)
          return@addSnapshotListener
        }
        if (snapshots != null) {
          scope.launch(Dispatchers.IO) {
            for (doc in snapshots.documents) {
              val data = doc.data ?: continue
              val id = doc.id
              val userEmail = data["userEmail"] as? String ?: continue
              val userName = data["userName"] as? String ?: ""
              val userPhone = data["userPhone"] as? String ?: ""
              val amount = (data["amount"] as? Number)?.toDouble() ?: 0.0
              val utrNumber = data["utrNumber"] as? String ?: ""
              val screenshotUri = data["screenshotUri"] as? String ?: ""
              val statusStr = data["status"] as? String ?: "PENDING"
              val status = try { RequestStatus.valueOf(statusStr) } catch (e: Exception) { RequestStatus.PENDING }
              val adminComment = data["adminComment"] as? String ?: ""
              val createdAt = (data["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
              val resolvedAt = (data["resolvedAt"] as? Number)?.toLong() ?: 0L

              val deposit = DepositRequest(
                id = id,
                userEmail = userEmail,
                userName = userName,
                userPhone = userPhone,
                amount = amount,
                utrNumber = utrNumber,
                screenshotUri = screenshotUri,
                status = status,
                adminComment = adminComment,
                createdAt = createdAt,
                resolvedAt = resolvedAt
              )
              database.walletDao().insertDepositRequest(deposit)
            }
            Log.d(TAG, "Synced ${snapshots.size()} deposit requests from Firestore")
          }
        }
      }

      // 6. Sync withdrawal requests in real-time
      val wCol = db.collection("withdrawal_requests")
      withdrawalsListener = wCol.addSnapshotListener { snapshots, error ->
        if (error != null) {
          handleFirestoreError(error, OperationType.LIST, wCol.path)
          return@addSnapshotListener
        }
        if (snapshots != null) {
          scope.launch(Dispatchers.IO) {
            for (doc in snapshots.documents) {
              val data = doc.data ?: continue
              val id = doc.id
              val userEmail = data["userEmail"] as? String ?: continue
              val userName = data["userName"] as? String ?: ""
              val amount = (data["amount"] as? Number)?.toDouble() ?: 0.0
              val upiId = data["upiId"] as? String ?: ""
              val accountHolderName = data["accountHolderName"] as? String ?: ""
              val statusStr = data["status"] as? String ?: "PENDING"
              val status = try { RequestStatus.valueOf(statusStr) } catch (e: Exception) { RequestStatus.PENDING }
              val payoutReference = data["payoutReference"] as? String ?: ""
              val rejectReason = data["rejectReason"] as? String ?: ""
              val createdAt = (data["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
              val resolvedAt = (data["resolvedAt"] as? Number)?.toLong() ?: 0L

              val withdrawal = WithdrawalRequest(
                id = id,
                userEmail = userEmail,
                userName = userName,
                amount = amount,
                upiId = upiId,
                accountHolderName = accountHolderName,
                status = status,
                payoutReference = payoutReference,
                rejectReason = rejectReason,
                createdAt = createdAt,
                resolvedAt = resolvedAt
              )
              database.walletDao().insertWithdrawalRequest(withdrawal)
            }
            Log.d(TAG, "Synced ${snapshots.size()} withdrawal requests from Firestore")
          }
        }
      }

      // 7. Sync transactions in real-time
      val txCol = db.collection("transactions")
      transactionsListener = txCol.addSnapshotListener { snapshots, error ->
        if (error != null) {
          handleFirestoreError(error, OperationType.LIST, txCol.path)
          return@addSnapshotListener
        }
        if (snapshots != null) {
          scope.launch(Dispatchers.IO) {
            for (doc in snapshots.documents) {
              val data = doc.data ?: continue
              val id = doc.id
              val userEmail = data["userEmail"] as? String ?: continue
              val typeStr = data["type"] as? String ?: "DEPOSIT"
              val type = try { TransactionType.valueOf(typeStr) } catch (e: Exception) { TransactionType.DEPOSIT }
              val amount = (data["amount"] as? Number)?.toDouble() ?: 0.0
              val title = data["title"] as? String ?: ""
              val description = data["description"] as? String ?: ""
              val referenceId = data["referenceId"] as? String ?: ""
              val timestamp = (data["timestamp"] as? Number)?.toLong() ?: System.currentTimeMillis()

              val tx = WalletTransaction(
                id = id,
                userEmail = userEmail,
                type = type,
                amount = amount,
                title = title,
                description = description,
                referenceId = referenceId,
                timestamp = timestamp
              )
              database.walletDao().insertTransaction(tx)
            }
            Log.d(TAG, "Synced ${snapshots.size()} transactions from Firestore")
          }
        }
      }

    } catch (e: Exception) {
      Log.e(TAG, "Error starting realtime sync", e)
    }
  }

  suspend fun syncUserToCloud(user: User) = withContext(Dispatchers.IO) {
    try {
      val docId = emailToDocId(user.email)
      val docRef = db.collection("users").document(docId)
      val data = hashMapOf<String, Any>(
        "userId" to docId,
        "email" to user.email,
        "fullName" to user.fullName,
        "phoneNumber" to user.phoneNumber,
        "freeFireUid" to user.freeFireUid,
        "freeFireIgn" to user.freeFireIgn,
        "referralCode" to user.referralCode,
        "referredByCode" to user.referredByCode,
        "password" to user.password,
        "walletBalance" to user.walletBalance,
        "totalDeposited" to user.totalDeposited,
        "totalWinnings" to user.totalWinnings,
        "totalWithdrawn" to user.totalWithdrawn,
        "reservedForWithdrawal" to user.reservedForWithdrawal,
        "isAdmin" to user.isAdmin,
        "createdAt" to user.createdAt,
        "updatedAt" to System.currentTimeMillis()
      )
      docRef.set(data, SetOptions.merge()).await()
      Log.d(TAG, "Successfully synced user ${user.email} to Firestore")
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "users/${emailToDocId(user.email)}")
      Log.e(TAG, "Failed to sync user to cloud", e)
    }
  }

  suspend fun fetchUserFromCloud(email: String): User? = withContext(Dispatchers.IO) {
    try {
      val docId = emailToDocId(email)
      val docRef = db.collection("users").document(docId)
      val snapshot = docRef.get().await()
      if (snapshot.exists()) {
        val data = snapshot.data ?: return@withContext null
        val user = User(
          email = data["email"] as? String ?: email,
          fullName = data["fullName"] as? String ?: "",
          phoneNumber = data["phoneNumber"] as? String ?: "",
          freeFireUid = data["freeFireUid"] as? String ?: "",
          freeFireIgn = data["freeFireIgn"] as? String ?: "",
          referralCode = data["referralCode"] as? String ?: "",
          referredByCode = data["referredByCode"] as? String ?: "",
          password = data["password"] as? String ?: "",
          walletBalance = (data["walletBalance"] as? Number)?.toDouble() ?: 0.0,
          totalDeposited = (data["totalDeposited"] as? Number)?.toDouble() ?: 0.0,
          totalWinnings = (data["totalWinnings"] as? Number)?.toDouble() ?: 0.0,
          totalWithdrawn = (data["totalWithdrawn"] as? Number)?.toDouble() ?: 0.0,
          reservedForWithdrawal = (data["reservedForWithdrawal"] as? Number)?.toDouble() ?: 0.0,
          isAdmin = data["isAdmin"] as? Boolean ?: false,
          createdAt = (data["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
        )
        // Cache to Room
        database.userDao().insertUser(user)
        return@withContext user
      }
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.GET, "users/${emailToDocId(email)}")
      Log.e(TAG, "Failed to fetch user from cloud", e)
    }
    null
  }

  suspend fun syncTournamentToCloud(t: Tournament) = withContext(Dispatchers.IO) {
    try {
      val docRef = db.collection("tournaments").document(t.id)
      val data = hashMapOf<String, Any>(
        "id" to t.id,
        "title" to t.title,
        "mapName" to t.mapName,
        "format" to t.format.name,
        "entryFee" to t.entryFee,
        "totalPrizePool" to t.totalPrizePool,
        "firstPrize" to t.firstPrize,
        "secondPrize" to t.secondPrize,
        "thirdPrize" to t.thirdPrize,
        "perKillBonus" to t.perKillBonus,
        "matchDate" to t.matchDate,
        "startTime" to t.startTime,
        "registrationClosingTime" to t.registrationClosingTime,
        "matchTimestamp" to t.matchTimestamp,
        "totalSlots" to t.totalSlots,
        "filledSlots" to t.filledSlots,
        "status" to t.status.name,
        "customRules" to t.customRules,
        "roomId" to t.roomId,
        "roomPassword" to t.roomPassword,
        "isRoomVisible" to t.isRoomVisible,
        "updatedAt" to System.currentTimeMillis()
      )
      docRef.set(data, SetOptions.merge()).await()
      Log.d(TAG, "Successfully synced tournament ${t.id} to Firestore")
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "tournaments/${t.id}")
      Log.e(TAG, "Failed to sync tournament to cloud", e)
    }
  }

  suspend fun deleteTournamentFromCloud(tournamentId: String) = withContext(Dispatchers.IO) {
    try {
      db.collection("tournaments").document(tournamentId).delete().await()
      Log.d(TAG, "Successfully deleted tournament $tournamentId from Firestore")
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "tournaments/$tournamentId")
      Log.e(TAG, "Failed to delete tournament from cloud", e)
    }
  }

  suspend fun syncRegistrationToCloud(reg: Registration) = withContext(Dispatchers.IO) {
    try {
      val docRef = db.collection("registrations").document(reg.id)
      val data = hashMapOf<String, Any>(
        "id" to reg.id,
        "tournamentId" to reg.tournamentId,
        "userEmail" to reg.userEmail,
        "teamName" to reg.teamName,
        "playerIgn" to reg.playerIgn,
        "playerUid" to reg.playerUid,
        "teammatesJson" to reg.teammatesJson,
        "entryFeePaid" to reg.entryFeePaid,
        "registeredAt" to reg.registeredAt,
        "kills" to reg.kills,
        "placementRank" to reg.placementRank,
        "prizeWon" to reg.prizeWon,
        "updatedAt" to System.currentTimeMillis()
      )
      docRef.set(data, SetOptions.merge()).await()
      Log.d(TAG, "Successfully synced registration ${reg.id} to Firestore")
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "registrations/${reg.id}")
      Log.e(TAG, "Failed to sync registration to cloud", e)
    }
  }

  suspend fun syncDepositRequestToCloud(req: DepositRequest) = withContext(Dispatchers.IO) {
    try {
      val docRef = db.collection("deposit_requests").document(req.id)
      val data = hashMapOf<String, Any>(
        "id" to req.id,
        "userEmail" to req.userEmail,
        "userName" to req.userName,
        "userPhone" to req.userPhone,
        "amount" to req.amount,
        "utrNumber" to req.utrNumber,
        "screenshotUri" to req.screenshotUri,
        "status" to req.status.name,
        "adminComment" to req.adminComment,
        "createdAt" to req.createdAt,
        "resolvedAt" to req.resolvedAt,
        "updatedAt" to System.currentTimeMillis()
      )
      docRef.set(data, SetOptions.merge()).await()
      Log.d(TAG, "Successfully synced deposit request ${req.id} to Firestore")
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "deposit_requests/${req.id}")
      Log.e(TAG, "Failed to sync deposit request to cloud", e)
    }
  }

  suspend fun syncWithdrawalRequestToCloud(req: WithdrawalRequest) = withContext(Dispatchers.IO) {
    try {
      val docRef = db.collection("withdrawal_requests").document(req.id)
      val data = hashMapOf<String, Any>(
        "id" to req.id,
        "userEmail" to req.userEmail,
        "userName" to req.userName,
        "amount" to req.amount,
        "upiId" to req.upiId,
        "accountHolderName" to req.accountHolderName,
        "status" to req.status.name,
        "payoutReference" to req.payoutReference,
        "rejectReason" to req.rejectReason,
        "createdAt" to req.createdAt,
        "resolvedAt" to req.resolvedAt,
        "updatedAt" to System.currentTimeMillis()
      )
      docRef.set(data, SetOptions.merge()).await()
      Log.d(TAG, "Successfully synced withdrawal request ${req.id} to Firestore")
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "withdrawal_requests/${req.id}")
      Log.e(TAG, "Failed to sync withdrawal request to cloud", e)
    }
  }

  suspend fun syncTransactionToCloud(tx: WalletTransaction) = withContext(Dispatchers.IO) {
    try {
      val docRef = db.collection("transactions").document(tx.id)
      val data = hashMapOf<String, Any>(
        "id" to tx.id,
        "userId" to emailToDocId(tx.userEmail),
        "userEmail" to tx.userEmail,
        "type" to tx.type.name,
        "amount" to tx.amount,
        "title" to tx.title,
        "description" to tx.description,
        "referenceId" to tx.referenceId,
        "timestamp" to tx.timestamp,
        "updatedAt" to System.currentTimeMillis()
      )
      docRef.set(data, SetOptions.merge()).await()
      Log.d(TAG, "Successfully synced transaction ${tx.id} to Firestore")
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "transactions/${tx.id}")
      Log.e(TAG, "Failed to sync transaction to cloud", e)
    }
  }

  suspend fun syncAppSettingsToCloud(settings: AppSettings) = withContext(Dispatchers.IO) {
    try {
      val docRef = db.collection("app_settings").document("global_config")
      val data = hashMapOf<String, Any>(
        "id" to "global_config",
        "adminUpiId" to settings.adminUpiId,
        "adminPayeeName" to settings.adminPayeeName,
        "telegramHelpUrl" to settings.telegramHelpUrl,
        "qrCodeImageUri" to settings.qrCodeImageUri,
        "supportContact" to settings.supportContact,
        "announcementNotice" to settings.announcementNotice,
        "minDepositAmount" to settings.minDepositAmount,
        "minWithdrawalAmount" to settings.minWithdrawalAmount,
        "isSampleDataSeeded" to settings.isSampleDataSeeded,
        "updatedAt" to System.currentTimeMillis()
      )
      docRef.set(data, SetOptions.merge()).await()
      Log.d(TAG, "Successfully synced AppSettings to Firestore")
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "app_settings/global_config")
      Log.e(TAG, "Failed to sync app settings to cloud", e)
    }
  }

  fun stopSync() {
    tournamentsListener?.remove()
    tournamentsListener = null
    settingsListener?.remove()
    settingsListener = null
    usersListener?.remove()
    usersListener = null
    registrationsListener?.remove()
    registrationsListener = null
    depositsListener?.remove()
    depositsListener = null
    withdrawalsListener?.remove()
    withdrawalsListener = null
    transactionsListener?.remove()
    transactionsListener = null
  }
}
